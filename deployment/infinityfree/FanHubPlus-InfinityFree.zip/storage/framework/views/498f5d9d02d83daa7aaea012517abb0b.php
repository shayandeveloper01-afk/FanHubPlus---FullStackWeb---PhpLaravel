<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($content->title); ?> — <?php echo e(config('app.name')); ?></title>

    
    <meta property="og:title"       content="<?php echo e($content->title); ?>">
    <meta property="og:description" content="<?php echo e(Str::limit(strip_tags($content->body), 160)); ?>">
    <meta property="og:image"       content="<?php echo e($content->thumbnailUrl()); ?>">
    <meta property="og:url"         content="<?php echo e(url()->current()); ?>">
    <meta property="og:type"        content="article">
    <meta name="twitter:card"       content="summary_large_image">

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600,700&display=swap" rel="stylesheet"/>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-950 text-white font-sans antialiased">


<?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<div class="relative h-64 sm:h-80 overflow-hidden">
    <?php if (isset($component)) { $__componentOriginal866276d147fd9806dc1448ec1d213bc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal866276d147fd9806dc1448ec1d213bc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.media-image','data' => ['src' => $content->thumbnailUrl(),'title' => $content->title,'category' => $content->category?->name ?? $content->type,'kind' => 'content','recordKey' => $content->id,'alt' => $content->title,'class' => 'w-full h-full object-cover opacity-40']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('media-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content->thumbnailUrl()),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content->title),'category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content->category?->name ?? $content->type),'kind' => 'content','record-key' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content->id),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content->title),'class' => 'w-full h-full object-cover opacity-40']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $attributes = $__attributesOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $component = $__componentOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__componentOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
    <div class="absolute inset-0 bg-gradient-to-t from-gray-950 via-gray-950/60 to-transparent"></div>
    <div class="absolute bottom-0 left-0 right-0 max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
        <div class="flex flex-wrap items-center gap-2 mb-2 text-xs text-gray-400">
            <a href="<?php echo e(route('explore', ['category' => $content->category_id])); ?>"
               class="text-indigo-400 font-semibold uppercase tracking-widest hover:text-indigo-300 transition">
                <?php echo e($content->category->name); ?>

            </a>
            <?php if($content->type): ?> <span>· <?php echo e(ucfirst($content->type)); ?></span> <?php endif; ?>
            <?php if($content->genre): ?> <span>· <?php echo e($content->genre); ?></span> <?php endif; ?>
            <?php if($content->year): ?>  <span>· <?php echo e($content->year); ?></span>  <?php endif; ?>
            <span>· <?php echo e($content->views_count); ?> views</span>
        </div>
        <h1 class="text-2xl sm:text-4xl font-bold leading-tight"><?php echo e($content->title); ?></h1>
        <p class="text-sm text-gray-400 mt-1">by <?php echo e($content->user->name); ?> · <?php echo e($content->created_at->format('d M Y')); ?></p>
    </div>
</div>

<div class="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 py-8 grid grid-cols-1 lg:grid-cols-3 gap-8">

    
    <div class="lg:col-span-2 space-y-10">

        
        <div x-data="{ tab: 'story' }" class="space-y-4">
            <?php if (isset($component)) { $__componentOriginal5caef62f42a5f8b9ce413e154657d2e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5caef62f42a5f8b9ce413e154657d2e2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tag-cloud','data' => ['tags' => $content->tags]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tag-cloud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tags' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content->tags)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5caef62f42a5f8b9ce413e154657d2e2)): ?>
<?php $attributes = $__attributesOriginal5caef62f42a5f8b9ce413e154657d2e2; ?>
<?php unset($__attributesOriginal5caef62f42a5f8b9ce413e154657d2e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5caef62f42a5f8b9ce413e154657d2e2)): ?>
<?php $component = $__componentOriginal5caef62f42a5f8b9ce413e154657d2e2; ?>
<?php unset($__componentOriginal5caef62f42a5f8b9ce413e154657d2e2); ?>
<?php endif; ?>
            <div class="flex gap-1 bg-gray-900 border border-gray-800 rounded-lg p-1 w-fit">
                <button @click="tab = 'facts'"
                        :class="tab === 'facts' ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:text-white'"
                        class="px-4 py-1.5 text-sm font-medium rounded-md transition">
                    Quick Facts
                </button>
                <button @click="tab = 'story'"
                        :class="tab === 'story' ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:text-white'"
                        class="px-4 py-1.5 text-sm font-medium rounded-md transition">
                    Full Story
                </button>
            </div>

            
            <div x-show="tab === 'facts'" x-transition:enter="transition ease-out duration-150"
                 x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100">
                <ul class="space-y-2 text-sm text-gray-300">
                    <?php if($content->category): ?>
                        <li class="flex gap-2"><span class="text-gray-500 w-24 shrink-0">Category</span> <?php echo e($content->category->name); ?></li>
                    <?php endif; ?>
                    <?php if($content->genre): ?>
                        <li class="flex gap-2"><span class="text-gray-500 w-24 shrink-0">Genre</span> <?php echo e($content->genre); ?></li>
                    <?php endif; ?>
                    <?php if($content->type): ?>
                        <li class="flex gap-2"><span class="text-gray-500 w-24 shrink-0">Type</span> <?php echo e(ucfirst($content->type)); ?></li>
                    <?php endif; ?>
                    <?php if($content->year): ?>
                        <li class="flex gap-2"><span class="text-gray-500 w-24 shrink-0">Year</span> <?php echo e($content->year); ?></li>
                    <?php endif; ?>
                    <li class="flex gap-2"><span class="text-gray-500 w-24 shrink-0">Views</span> <?php echo e(number_format($content->views_count)); ?></li>
                    <li class="flex gap-2"><span class="text-gray-500 w-24 shrink-0">Rating</span>
                        <?php echo e($content->averageRating() ? $content->averageRating() . '/5 (' . $content->ratingsCount() . ' ratings)' : 'No ratings yet'); ?>

                    </li>
                    <li class="flex gap-2"><span class="text-gray-500 w-24 shrink-0">Author</span> <?php echo e($content->user->name); ?></li>
                    <li class="flex gap-2"><span class="text-gray-500 w-24 shrink-0">Published</span> <?php echo e($content->created_at->format('d M Y')); ?></li>
                </ul>
            </div>

            
            <div x-show="tab === 'story'" x-transition:enter="transition ease-out duration-150"
                 x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
                 class="prose prose-invert prose-sm sm:prose max-w-none leading-relaxed">
                <?php echo nl2br(e($content->body)); ?>

            </div>
        </div>

        
        <?php $trailer = $content->trailerEmbed(); ?>
        <?php if($trailer): ?>
            <section>
                <div class="mb-4 flex flex-wrap items-center justify-between gap-3 border-b border-gray-800 pb-2">
                    <h2 class="text-lg font-semibold">Watch video</h2>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if (isset($component)) { $__componentOriginald3b08a67ce4bee249aa12c2a049bc195 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald3b08a67ce4bee249aa12c2a049bc195 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bookmark-button','data' => ['content' => $content,'bookmarked' => $userBookmarked,'showLabel' => true,'class' => 'inline-flex min-h-10 items-center gap-2 rounded-lg border border-indigo-400/40 bg-indigo-600/15 px-4 py-2 text-sm font-semibold text-indigo-200 transition hover:bg-indigo-600/30']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bookmark-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['content' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content),'bookmarked' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($userBookmarked),'show-label' => true,'class' => 'inline-flex min-h-10 items-center gap-2 rounded-lg border border-indigo-400/40 bg-indigo-600/15 px-4 py-2 text-sm font-semibold text-indigo-200 transition hover:bg-indigo-600/30']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald3b08a67ce4bee249aa12c2a049bc195)): ?>
<?php $attributes = $__attributesOriginald3b08a67ce4bee249aa12c2a049bc195; ?>
<?php unset($__attributesOriginald3b08a67ce4bee249aa12c2a049bc195); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald3b08a67ce4bee249aa12c2a049bc195)): ?>
<?php $component = $__componentOriginald3b08a67ce4bee249aa12c2a049bc195; ?>
<?php unset($__componentOriginald3b08a67ce4bee249aa12c2a049bc195); ?>
<?php endif; ?>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="inline-flex items-center gap-2 rounded-lg border border-gray-700 px-4 py-2 text-sm font-semibold text-gray-200 transition hover:border-indigo-400">
                            Sign in to bookmark
                        </a>
                    <?php endif; ?>
                </div>
                <div class="aspect-video w-full overflow-hidden rounded-xl border border-gray-800 bg-black">
                    <?php if($trailer['type'] === 'iframe'): ?>
                        <iframe src="<?php echo e($trailer['src']); ?>"
                                title="<?php echo e($content->title); ?> video"
                                class="w-full h-full"
                                loading="lazy"
                                allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                                referrerpolicy="strict-origin-when-cross-origin"
                                allowfullscreen></iframe>
                    <?php else: ?>
                        <video controls preload="metadata" playsinline poster="<?php echo e($content->thumbnailUrl()); ?>" class="w-full h-full">
                            <source src="<?php echo e($trailer['src']); ?>">
                            Aap ka browser video support nahi karta.
                        </video>
                    <?php endif; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if($content->characters->isNotEmpty()): ?>
        <section>
            <h2 class="text-lg font-semibold mb-4 border-b border-gray-800 pb-2">Characters</h2>
            <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                <?php $__currentLoopData = $content->characters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $char): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-gray-900 rounded-lg p-3 text-center">
                    <?php if (isset($component)) { $__componentOriginal866276d147fd9806dc1448ec1d213bc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal866276d147fd9806dc1448ec1d213bc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.media-image','data' => ['src' => $char->imageUrl(),'title' => $char->name,'category' => $content->category?->name ?? 'Character','kind' => 'character','recordKey' => $char->id,'alt' => $char->name,'class' => 'w-16 h-16 rounded-full object-cover mx-auto mb-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('media-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($char->imageUrl()),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($char->name),'category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content->category?->name ?? 'Character'),'kind' => 'character','record-key' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($char->id),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($char->name),'class' => 'w-16 h-16 rounded-full object-cover mx-auto mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $attributes = $__attributesOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $component = $__componentOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__componentOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
                    <p class="text-sm font-semibold leading-tight"><?php echo e($char->name); ?></p>
                    <?php if($char->alias): ?>
                        <p class="text-xs text-gray-400">"<?php echo e($char->alias); ?>"</p>
                    <?php endif; ?>
                    <span class="inline-block mt-1 text-[10px] px-2 py-0.5 rounded-full
                        <?php echo e(match($char->role) {
                            'protagonist' => 'bg-indigo-600/30 text-indigo-300',
                            'antagonist'  => 'bg-red-600/30 text-red-300',
                            'supporting'  => 'bg-gray-700 text-gray-300',
                            default       => 'bg-gray-800 text-gray-400',
                        }); ?>">
                        <?php echo e(ucfirst($char->role)); ?>

                    </span>
                    <?php if($char->description): ?>
                        <p class="text-xs text-gray-500 mt-1 line-clamp-2"><?php echo e($char->description); ?></p>
                    <?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
        <?php endif; ?>

        
        <?php if($content->timelineEvents->isNotEmpty()): ?>
        <section>
            <h2 class="text-lg font-semibold mb-4 border-b border-gray-800 pb-2">Timeline</h2>
            <div class="relative pl-6 border-l-2 border-indigo-600/40 space-y-6">
                <?php $__currentLoopData = $content->timelineEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="relative">
                    <div class="absolute -left-[1.35rem] top-1 w-3 h-3 rounded-full bg-indigo-500 border-2 border-gray-950"></div>
                    <div class="bg-gray-900 rounded-lg p-4">
                        <div class="flex items-center gap-3 mb-1">
                            <p class="font-semibold text-sm"><?php echo e($event->title); ?></p>
                            <?php if($event->event_date): ?>
                                <span class="text-xs text-gray-500"><?php echo e($event->event_date->format('d M Y')); ?></span>
                            <?php endif; ?>
                        </div>
                        <?php if($event->description): ?>
                            <p class="text-sm text-gray-400"><?php echo e($event->description); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
        <?php endif; ?>

        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $content)): ?>
        <section x-data="{ openChar: false, openTimeline: false }">
            <div class="flex gap-3 flex-wrap">
                <button @click="openChar = !openChar"
                        class="text-sm bg-gray-800 hover:bg-gray-700 border border-gray-700 px-4 py-2 rounded-lg transition">
                    + Add Character
                </button>
                <button @click="openTimeline = !openTimeline"
                        class="text-sm bg-gray-800 hover:bg-gray-700 border border-gray-700 px-4 py-2 rounded-lg transition">
                    + Add Timeline Event
                </button>
                <a href="<?php echo e(route('contents.edit', $content)); ?>"
                   class="text-sm bg-indigo-600 hover:bg-indigo-700 px-4 py-2 rounded-lg transition">
                    Edit Content
                </a>
            </div>

            
            <div x-show="openChar" x-transition class="mt-4 bg-gray-900 border border-gray-800 rounded-lg p-5">
                <h3 class="font-semibold mb-4 text-sm">Add Character</h3>
                <form method="POST" action="<?php echo e(route('characters.store', $content)); ?>"
                      enctype="multipart/form-data" class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label class="block text-xs text-gray-400 mb-1">Name *</label>
                        <input name="name" required class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    <div>
                        <label class="block text-xs text-gray-400 mb-1">Alias</label>
                        <input name="alias" class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    <div>
                        <label class="block text-xs text-gray-400 mb-1">Role *</label>
                        <select name="role" class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <?php $__currentLoopData = ['protagonist','antagonist','supporting','other']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($r); ?>"><?php echo e(ucfirst($r)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs text-gray-400 mb-1">Order</label>
                        <input name="order_index" type="number" min="0" value="0"
                               class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    <div class="sm:col-span-2">
                        <label class="block text-xs text-gray-400 mb-1">Description</label>
                        <textarea name="description" rows="2"
                                  class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"></textarea>
                    </div>
                    <div class="sm:col-span-2">
                        <label class="block text-xs text-gray-400 mb-1">Image</label>
                        <input name="image" type="file" accept="image/*"
                               class="text-sm text-gray-400 file:mr-3 file:py-1 file:px-3 file:rounded file:border-0 file:text-sm file:bg-gray-700 file:text-gray-200">
                    </div>
                    <div class="sm:col-span-2">
                        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white text-sm px-5 py-2 rounded-lg transition">
                            Save Character
                        </button>
                    </div>
                </form>
            </div>

            
            <div x-show="openTimeline" x-transition class="mt-4 bg-gray-900 border border-gray-800 rounded-lg p-5">
                <h3 class="font-semibold mb-4 text-sm">Add Timeline Event</h3>
                <form method="POST" action="<?php echo e(route('timeline.store', $content)); ?>"
                      class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label class="block text-xs text-gray-400 mb-1">Title *</label>
                        <input name="title" required class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    <div>
                        <label class="block text-xs text-gray-400 mb-1">Date (optional)</label>
                        <input name="event_date" type="date"
                               class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    <div class="sm:col-span-2">
                        <label class="block text-xs text-gray-400 mb-1">Description</label>
                        <textarea name="description" rows="2"
                                  class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"></textarea>
                    </div>
                    <div>
                        <label class="block text-xs text-gray-400 mb-1">Order</label>
                        <input name="order_index" type="number" min="0" value="0"
                               class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    <div class="sm:col-span-2">
                        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white text-sm px-5 py-2 rounded-lg transition">
                            Save Event
                        </button>
                    </div>
                </form>
            </div>
        </section>
        <?php endif; ?>

    </div>
    
    <div class="space-y-6">

        
        <div class="bg-gray-900 rounded-xl p-5 space-y-4">

            
        <?php if(auth()->guard()->check()): ?>
        <?php if($profile): ?>
            <div x-data="myListWidget(<?php echo e($inList ? 'true' : 'false'); ?>, <?php echo e($content->id); ?>)">
                <button @click="toggle()"
                        :class="inList ? 'bg-green-700 hover:bg-green-600' : 'bg-gray-800 hover:bg-gray-700 border border-gray-700'"
                        class="flex items-center gap-2 text-sm px-4 py-2 rounded-lg transition-all duration-200 font-medium">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path x-show="!inList" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                        <path x-show="inList" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                    </svg>
                    <span x-text="inList ? '✓ In My List' : '+ My List'"></span>
                </button>
                <p x-show="msg" x-text="msg" class="text-xs text-gray-400 mt-1" x-cloak></p>
            </div>
            <?php endif; ?>
            <?php else: ?>
            <a href="<?php echo e(route('login')); ?>"
               class="flex items-center gap-2 text-sm bg-gray-800 hover:bg-gray-700 border border-gray-700 px-4 py-2 rounded-lg transition">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"/>
                </svg>
                Sign in to access member features
            </a>
            <?php endif; ?>

            
            <div>
                <p class="text-xs text-gray-500 uppercase tracking-widest mb-2">Share</p>
                <div class="flex gap-2 flex-wrap">
                    <?php $shareUrl = urlencode(url()->current()); $shareTitle = urlencode($content->title); ?>
                    <a href="https://twitter.com/intent/tweet?url=<?php echo e($shareUrl); ?>&text=<?php echo e($shareTitle); ?>"
                       target="_blank" rel="noopener" data-fh-share="twitter"
                       class="text-xs bg-gray-800 hover:bg-sky-600 border border-gray-700 px-3 py-1.5 rounded-lg transition flex items-center gap-1.5">
                        <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.73-8.835L1.254 2.25H8.08l4.253 5.622zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                        X
                    </a>
                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($shareUrl); ?>"
                       target="_blank" rel="noopener" data-fh-share="facebook"
                       class="text-xs bg-gray-800 hover:bg-blue-600 border border-gray-700 px-3 py-1.5 rounded-lg transition flex items-center gap-1.5">
                        <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                        Facebook
                    </a>
                    <a href="https://wa.me/?text=<?php echo e($shareTitle); ?>%20<?php echo e($shareUrl); ?>"
                       target="_blank" rel="noopener" data-fh-share="whatsapp"
                       class="text-xs bg-gray-800 hover:bg-green-600 border border-gray-700 px-3 py-1.5 rounded-lg transition flex items-center gap-1.5">
                        <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                        WhatsApp
                    </a>
                    <a href="https://www.reddit.com/submit?url=<?php echo e($shareUrl); ?>&title=<?php echo e($shareTitle); ?>"
                       target="_blank" rel="noopener" data-fh-share="reddit"
                       class="text-xs bg-gray-800 hover:bg-orange-600 border border-gray-700 px-3 py-1.5 rounded-lg transition">Reddit</a>
                    <button data-fh-share="copy" onclick="navigator.clipboard.writeText('<?php echo e(url()->current()); ?>').then(() => alert('Link copied!'))"
                            class="text-xs bg-gray-800 hover:bg-gray-700 border border-gray-700 px-3 py-1.5 rounded-lg transition">
                        Copy Link
                    </button>
                </div>
            </div>
        </div>

        
        <div class="bg-gray-900 rounded-xl p-5">
            <p class="text-xs text-gray-500 uppercase tracking-widest mb-3">Rating</p>
            <div class="flex items-center gap-3 mb-3">
                <span class="text-3xl font-bold text-yellow-400">
                    <?php echo e($content->averageRating() ?? '—'); ?>

                </span>
                <div>
                    <p class="text-sm text-gray-300">out of 5</p>
                    <p class="text-xs text-gray-500"><?php echo e($content->ratingsCount()); ?> <?php echo e(Str::plural('rating', $content->ratingsCount())); ?></p>
                </div>
            </div>

            <?php if(auth()->guard()->check()): ?>
            <form method="POST" action="<?php echo e(route('ratings.store', $content)); ?>" class="space-y-3">
                <?php echo csrf_field(); ?>
                <p class="text-xs text-gray-400">Your rating:</p>
                <div class="flex gap-1">
                    <?php for($i = 1; $i <= 5; $i++): ?>
                    <input class="peer sr-only" type="radio" id="rating-<?php echo e($i); ?>" name="rating" value="<?php echo e($i); ?>" required <?php if((int) old('rating', $userRating ?? 0) === $i): echo 'checked'; endif; ?>>
                    <label for="rating-<?php echo e($i); ?>" class="cursor-pointer text-3xl leading-none text-gray-600 transition hover:scale-110 hover:text-yellow-300 peer-checked:text-yellow-400" aria-label="Rate <?php echo e($i); ?> stars">&#9733;</label>
                    <?php endfor; ?>
                </div>
                <label class="block text-xs text-gray-400" for="rating-review">Review (optional)</label>
                <textarea id="rating-review" name="review" maxlength="2000" rows="3" class="w-full rounded-lg border border-gray-700 bg-gray-800 p-2 text-sm text-white" placeholder="What did you think?"><?php echo e(old('review', $userReview ?? '')); ?></textarea>
                <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-sm text-red-300" role="alert"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['review'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-sm text-red-300" role="alert"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php if(session('rating_saved')): ?><p class="text-sm text-green-300" role="status"><?php echo e(session('rating_saved')); ?></p><?php endif; ?>
                <?php if($userReviewStatus === 'pending'): ?><p class="text-sm text-amber-300" role="status">Your review is waiting for admin approval.</p><?php elseif($userReviewStatus === 'rejected'): ?><p class="text-sm text-rose-300" role="status">Your last review was not approved. You can edit and resubmit it for review.</p><?php endif; ?>
                <button type="submit" class="inline-flex min-h-12 items-center justify-center rounded-lg bg-indigo-600 px-7 py-3 text-base font-bold text-white shadow-lg transition hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-300">Submit rating &amp; review</button>
            </form>
            <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="text-sm text-indigo-400 hover:text-indigo-300 transition">
                Sign in to rate
            </a>
            <?php endif; ?>
        </div>

        <?php if($reviews->isNotEmpty()): ?>
        <div class="bg-gray-900 rounded-xl p-5 space-y-3">
            <h3 class="text-sm font-semibold text-white">Community reviews</h3>
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reviewEntry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="rounded-lg bg-gray-800/70 p-3">
                <div class="flex items-center justify-between gap-3">
                    <p class="text-sm font-medium text-white"><?php echo e($reviewEntry->user?->name ?? 'FanHub member'); ?></p>
                    <p class="text-sm text-yellow-400"><?php echo e(str_repeat('★', $reviewEntry->rating)); ?><span class="text-gray-600"><?php echo e(str_repeat('★', 5 - $reviewEntry->rating)); ?></span></p>
                </div>
                <p class="mt-2 whitespace-pre-line text-sm text-gray-300"><?php echo e($reviewEntry->review); ?></p>
                <?php if($reviewEntry->admin_reaction || $reviewEntry->admin_reply): ?>
                    <div class="mt-3 rounded-lg border border-violet-400/15 bg-violet-500/5 p-3">
                        <p class="text-xs font-semibold uppercase tracking-wide text-violet-200">FanHub admin<?php echo e($reviewEntry->admin_reaction ? ' · ' . ucfirst($reviewEntry->admin_reaction) : ''); ?></p>
                        <?php if($reviewEntry->admin_reply): ?><p class="mt-1 whitespace-pre-line text-sm text-gray-300"><?php echo e($reviewEntry->admin_reply); ?></p><?php endif; ?>
                    </div>
                <?php endif; ?>
                <time class="mt-2 block text-xs text-gray-500" datetime="<?php echo e($reviewEntry->created_at?->toIso8601String()); ?>"><?php echo e($reviewEntry->created_at?->diffForHumans()); ?></time>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        
        <?php if(auth()->guard()->check()): ?>
        <div class="bg-gray-900 rounded-xl p-5">
            <p class="text-xs text-gray-500 uppercase tracking-widest mb-3">My Private Note</p>
            <form method="POST" action="<?php echo e(route('notes.upsert', $content)); ?>" class="space-y-3">
                <?php echo csrf_field(); ?>
                <textarea name="note" rows="4" required maxlength="5000" placeholder="Write a private note about this content..." class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"><?php echo e(old('note', $userNote ?? '')); ?></textarea>
                <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-sm text-red-300" role="alert"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="flex flex-wrap items-center gap-4 text-sm text-gray-300">
                    <label class="flex items-center gap-2">Timestamp (seconds)
                        <input type="number" name="timestamp_seconds" min="0" value="<?php echo e(old('timestamp_seconds', $noteDetails?->timestamp_seconds)); ?>" class="w-28 rounded bg-gray-800 border border-gray-700 px-2 py-1 text-white">
                    </label>
                    <label class="flex items-center gap-2"><input type="checkbox" name="is_spoiler" value="1" <?php if(old('is_spoiler', $noteDetails?->is_spoiler)): echo 'checked'; endif; ?>> Contains spoilers</label>
                </div>
                <?php if(old('is_spoiler', $noteDetails?->is_spoiler)): ?><p class="text-xs text-amber-300" role="status">Spoiler warning: this note includes story details.</p><?php endif; ?>
                <?php if(session('note_saved')): ?><p class="text-sm text-green-300" role="status"><?php echo e(session('note_saved')); ?></p><?php endif; ?>
                <button type="submit" class="inline-flex min-h-11 items-center justify-center rounded-lg bg-indigo-600 px-6 py-2.5 text-base font-bold text-white shadow-md transition hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-300">Save Note</button>
            </form>
            <?php if($userNote): ?>
            <form method="POST" action="<?php echo e(route('notes.destroy', $content)); ?>" class="mt-2">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="text-sm font-semibold text-red-400 transition hover:text-red-300">Delete private note</button>
            </form>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
        <div class="rounded-xl border border-gray-800 bg-gray-900 p-5">
            <p class="text-sm text-gray-300">Private notes are only available to signed-in members.</p>
            <a href="<?php echo e(route('login')); ?>" class="mt-3 inline-flex min-h-10 items-center rounded-lg bg-indigo-600 px-5 py-2 font-semibold text-white transition hover:bg-indigo-500">Sign in to write a note</a>
        </div>
        <?php endif; ?>

    </div>
</div>


<?php if($related->isNotEmpty()): ?>
<div class="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 py-8 border-t border-gray-800">

    
    <?php if($playNext): ?>
    <div class="flex items-center justify-between mb-4 flex-wrap gap-3">
        <h2 class="text-base sm:text-lg font-semibold text-white">Up Next</h2>
        <a href="<?php echo e(route('contents.show', $playNext)); ?>"
           class="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium px-5 py-2 rounded-lg transition">
            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                <path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z"/>
            </svg>
            Play Next: <?php echo e(Str::limit($playNext->title, 40)); ?>

        </a>
    </div>
    <?php endif; ?>

    
    <h2 class="text-base sm:text-lg font-semibold text-white mb-3">More Like This</h2>
    <div class="flex gap-3 overflow-x-auto scroll-smooth pb-2 scrollbar-hide snap-x snap-mandatory">
        <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="snap-start flex-shrink-0 w-36 sm:w-44 group relative rounded-lg overflow-hidden bg-gray-800 shadow-lg
                    transition-transform duration-200 hover:scale-105 hover:z-10">
            <div class="aspect-[2/3] overflow-hidden bg-gray-700">
                <?php if (isset($component)) { $__componentOriginal866276d147fd9806dc1448ec1d213bc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal866276d147fd9806dc1448ec1d213bc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.media-image','data' => ['src' => $item->thumbnailUrl(),'title' => $item->title,'category' => $item->category?->name ?? $item->type,'kind' => 'content','recordKey' => $item->id,'alt' => $item->title,'class' => 'w-full h-full object-cover']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('media-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->thumbnailUrl()),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->title),'category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->category?->name ?? $item->type),'kind' => 'content','record-key' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->id),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->title),'class' => 'w-full h-full object-cover']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $attributes = $__attributesOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $component = $__componentOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__componentOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
            </div>
            <div class="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-2">
                <p class="text-white text-xs font-semibold leading-tight line-clamp-2"><?php echo e($item->title); ?></p>
                <p class="text-indigo-300 text-[10px] mt-0.5"><?php echo e($item->category->name); ?></p>
            </div>
            <a href="<?php echo e(route('contents.show', $item)); ?>" class="absolute inset-0" aria-label="View <?php echo e($item->title); ?>"></a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>



<?php $__env->startPush('scripts'); ?>
<script>
function myListWidget(initial, contentId) {
    return {
        inList: initial,
        msg: '',
        async toggle() {
            try {
                const res = await fetch(`/my-list/${contentId}/toggle`, {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                    },
                });
                const data = await res.json();
                if (data.error) { this.msg = data.error; return; }
                this.inList = data.in_list;
                this.msg = data.in_list ? '✓ Added to My List' : 'Removed from My List';
                setTimeout(() => this.msg = '', 2000);
            } catch {
                this.msg = 'Something went wrong.';
            }
        }
    };
}

document.querySelectorAll('[data-fh-share]').forEach((button) => {
    button.addEventListener('click', () => {
        fetch('<?php echo e(route('analytics.track')); ?>', {
            method: 'POST',
            keepalive: true,
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                'Content-Type': 'application/json',
                'Accept': 'application/json',
            },
            body: JSON.stringify({ event_type: 'share_clicked', metadata: { content_id: <?php echo e($content->id); ?>, platform: button.dataset.fhShare } }),
        }).catch(() => {});
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus\resources\views/contents/show.blade.php ENDPATH**/ ?>