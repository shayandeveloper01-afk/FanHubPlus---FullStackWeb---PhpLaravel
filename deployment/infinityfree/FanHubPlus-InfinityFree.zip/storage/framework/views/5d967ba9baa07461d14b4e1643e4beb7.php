<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h1 class="text-lg font-semibold text-white">Settings</h1>
     <?php $__env->endSlot(); ?>

    <div class="max-w-2xl">
        <form method="POST" action="<?php echo e(route('admin.settings.update')); ?>" class="space-y-6">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

            <div class="bg-gray-900 border border-gray-800 rounded-xl p-6 space-y-5">
                <h2 class="text-sm font-semibold text-white border-b border-gray-800 pb-3">General</h2>

                <div>
                    <label class="block text-xs text-gray-400 mb-1">Site Name</label>
                    <input type="text" name="site_name"
                           value="<?php echo e($settings['site_name'] ?? config('app.name')); ?>"
                           class="w-full bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500">
                </div>

                <div>
                    <label class="block text-xs text-gray-400 mb-1">Contact Email</label>
                    <input type="email" name="contact_email"
                           value="<?php echo e($settings['contact_email'] ?? ''); ?>"
                           class="w-full bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500">
                </div>
            </div>

            <div class="bg-gray-900 border border-gray-800 rounded-xl p-6 space-y-5">
                <h2 class="text-sm font-semibold text-white border-b border-gray-800 pb-3">Chatbot</h2>

                <div>
                    <label class="block text-xs text-gray-400 mb-1">Fallback Message</label>
                    <textarea name="chatbot_fallback_message" rows="3"
                              class="w-full bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500"><?php echo e($settings['chatbot_fallback_message'] ?? ''); ?></textarea>
                    <p class="text-xs text-gray-600 mt-1">Shown when no FAQ matches. Leave blank to use the default.</p>
                </div>
            </div>

            <div class="bg-gray-900 border border-gray-800 rounded-xl p-6 space-y-5">
                <h2 class="text-sm font-semibold text-white border-b border-gray-800 pb-3">Feedback</h2>

                <div>
                    <label class="block text-xs text-gray-400 mb-1">Feedback Categories (comma-separated)</label>
                    <input type="text" name="feedback_categories"
                           value="<?php echo e($settings['feedback_categories'] ?? 'bug,suggestion,general,report'); ?>"
                           class="w-full bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500">
                    <p class="text-xs text-gray-600 mt-1">Changing this only affects display labels — existing DB values are unchanged.</p>
                </div>
            </div>

            <div class="bg-gray-900 border border-gray-800 rounded-xl p-6">
                <h2 class="text-sm font-semibold text-white border-b border-gray-800 pb-3 mb-4">Maintenance</h2>

                <label class="flex items-center gap-3 cursor-pointer">
                    <input type="hidden" name="maintenance_mode" value="0">
                    <input type="checkbox" name="maintenance_mode" value="1"
                           <?php echo e(($settings['maintenance_mode'] ?? '0') === '1' ? 'checked' : ''); ?>

                           class="w-4 h-4 rounded border-gray-600 bg-gray-800 text-indigo-600 focus:ring-indigo-500">
                    <span class="text-sm text-white">Enable Maintenance Mode</span>
                </label>
                <p class="text-xs text-gray-600 mt-2 ml-7">
                    When on, non-admin visitors see a maintenance page. Admins are unaffected.
                </p>
            </div>

            <div class="flex justify-end">
                <button type="submit"
                        class="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium rounded-lg transition">
                    Save Settings
                </button>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\admin\settings\index.blade.php ENDPATH**/ ?>