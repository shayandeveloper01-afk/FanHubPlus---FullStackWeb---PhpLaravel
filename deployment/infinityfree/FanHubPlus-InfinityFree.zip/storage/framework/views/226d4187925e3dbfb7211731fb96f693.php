<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['event']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['event']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div class="fh-event-art-fallback" role="img" aria-label="Event: <?php echo e($event->category?->name ?? 'Community event'); ?> in <?php echo e($event->city); ?>">
    <span>EVENT</span>
    <strong><?php echo e($event->category?->name ?? 'Community event'); ?></strong>
    <small><?php echo e($event->city); ?></small>
</div>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\components\event-art-fallback.blade.php ENDPATH**/ ?>