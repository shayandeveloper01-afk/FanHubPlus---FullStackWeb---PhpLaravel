<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title',
    'items',
    'myListIds' => [],
    'progress' => [],
    'matchScores' => [],
    'showNew' => false,
    'ranked' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title',
    'items',
    'myListIds' => [],
    'progress' => [],
    'matchScores' => [],
    'showNew' => false,
    'ranked' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div x-data="{ canLeft: false, canRight: true }"
     x-init="
        const el = $refs.track;
        const update = () => {
            canLeft = el.scrollLeft > 4;
            canRight = el.scrollLeft < (el.scrollWidth - el.clientWidth - 4);
        };
        update();
        el.addEventListener('scroll', update, { passive: true });
        window.addEventListener('resize', update);
     "
     class="relative group/row">

    <div class="flex items-center justify-between mb-3 px-1">
        <h2 class="text-base sm:text-lg font-semibold text-white"><?php echo e($title); ?></h2>
    </div>

    <div class="relative">
        
        <button x-show="canLeft" x-transition.opacity @click="$refs.track.scrollBy({ left: -$refs.track.clientWidth * 0.85, behavior: 'smooth' })"
                class="hidden sm:flex absolute -left-3 top-0 bottom-8 z-20 w-10 items-center justify-center
                       bg-gradient-to-r from-gray-950 via-gray-950/80 to-transparent
                       opacity-0 group-hover/row:opacity-100 transition-opacity">
            <span class="w-8 h-8 rounded-full bg-black/60 backdrop-blur flex items-center justify-center">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
            </span>
        </button>

        
        <button x-show="canRight" x-transition.opacity @click="$refs.track.scrollBy({ left: $refs.track.clientWidth * 0.85, behavior: 'smooth' })"
                class="hidden sm:flex absolute -right-3 top-0 bottom-8 z-20 w-10 items-center justify-center
                       bg-gradient-to-l from-gray-950 via-gray-950/80 to-transparent
                       opacity-0 group-hover/row:opacity-100 transition-opacity">
            <span class="w-8 h-8 rounded-full bg-black/60 backdrop-blur flex items-center justify-center">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
            </span>
        </button>

        <div x-ref="track"
             class="flex gap-3 sm:gap-4 overflow-x-auto scroll-smooth pb-8 scrollbar-hide snap-x snap-mandatory">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $inList = in_array($item->id, $myListIds ?? []);
                    $pct = $progress[$item->id] ?? null;
                    $match = $matchScores[$item->id] ?? null;
                    $isNew = $showNew ?? false;
                    $poster = method_exists($item, 'thumbnailUrl') ? $item->thumbnailUrl() : null;
                ?>
                <a href="<?php echo e(route('contents.show', $item)); ?>" data-content-id="<?php echo e($item->id); ?>"
                   <?php if(!empty($item->trailer_url)): ?> data-trailer="<?php echo e($item->trailer_url); ?>" <?php endif; ?>
                   class="fh-card snap-start flex-shrink-0 <?php echo e($ranked ? 'w-40 sm:w-48' : 'w-40 sm:w-48'); ?> relative rounded-xl overflow-hidden bg-gray-900 border border-gray-800/80 hover:border-indigo-500/50">

                    <div class="relative aspect-[2/3] overflow-hidden bg-gray-800 fh-skel">
                        <?php if (isset($component)) { $__componentOriginal866276d147fd9806dc1448ec1d213bc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal866276d147fd9806dc1448ec1d213bc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.media-image','data' => ['src' => $poster,'title' => $item->title,'category' => $item->category?->name ?? $item->type,'kind' => 'content','recordKey' => $item->id,'alt' => $item->title,'class' => 'w-full h-full object-cover transition-transform duration-500 group-hover:scale-105']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('media-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($poster),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->title),'category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->category?->name ?? $item->type),'kind' => 'content','record-key' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->id),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->title),'class' => 'w-full h-full object-cover transition-transform duration-500 group-hover:scale-105']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $attributes = $__attributesOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $component = $__componentOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__componentOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>

                        <?php if(!empty($item->trailer_url)): ?>
                            <video class="trailer-video absolute inset-0 w-full h-full object-cover opacity-0 [.fh-card:hover_&]:opacity-100 transition-opacity duration-300"
                                   src="<?php echo e($item->trailer_url); ?>" muted loop playsinline></video>
                        <?php endif; ?>

                        <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent"></div>

                        
                        <?php if($ranked): ?>
                            <span class="absolute -left-1 -bottom-3 text-6xl font-black text-white/10 leading-none select-none"
                                  style="-webkit-text-stroke:1px rgba(255,255,255,.25);"><?php echo e($i + 1); ?></span>
                        <?php endif; ?>

                        
                        <?php if($isNew): ?>
                            <span class="absolute top-2 left-2 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-indigo-600 text-white">NEW</span>
                        <?php endif; ?>

                        
                        <?php if($match): ?>
                            <span class="absolute top-2 right-2 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/90 text-black"><?php echo e($match); ?>% match</span>
                        <?php endif; ?>

                        
                        <?php if (isset($component)) { $__componentOriginald3b08a67ce4bee249aa12c2a049bc195 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald3b08a67ce4bee249aa12c2a049bc195 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bookmark-button','data' => ['content' => $item,'showLabel' => true,'class' => 'absolute top-2 right-2 z-[5] inline-flex min-h-8 items-center gap-1.5 rounded-full bg-black/75 px-2.5 text-xs font-semibold text-white backdrop-blur transition hover:bg-purple-700']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bookmark-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['content' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item),'show-label' => true,'class' => 'absolute top-2 right-2 z-[5] inline-flex min-h-8 items-center gap-1.5 rounded-full bg-black/75 px-2.5 text-xs font-semibold text-white backdrop-blur transition hover:bg-purple-700']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald3b08a67ce4bee249aa12c2a049bc195)): ?>
<?php $attributes = $__attributesOriginald3b08a67ce4bee249aa12c2a049bc195; ?>
<?php unset($__attributesOriginald3b08a67ce4bee249aa12c2a049bc195); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald3b08a67ce4bee249aa12c2a049bc195)): ?>
<?php $component = $__componentOriginald3b08a67ce4bee249aa12c2a049bc195; ?>
<?php unset($__componentOriginald3b08a67ce4bee249aa12c2a049bc195); ?>
<?php endif; ?>
                        <button type="button"
                                class="mylist-btn absolute bottom-2 right-2 w-7 h-7 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur flex items-center justify-center transition"
                                data-content-id="<?php echo e($item->id); ?>" data-in-list="<?php echo e($inList ? 'true' : 'false'); ?>"
                                aria-label="<?php echo e($inList ? 'Remove from My List' : 'Add to My List'); ?>">
                            <svg class="w-3.5 h-3.5 mylist-icon-add <?php echo e($inList ? 'hidden' : ''); ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                            </svg>
                            <svg class="w-3.5 h-3.5 mylist-icon-check <?php echo e($inList ? '' : 'hidden'); ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                            </svg>
                        </button>

                        
                        <?php if(!is_null($pct)): ?>
                            <div class="absolute left-0 right-0 bottom-0 h-1 bg-white/20">
                                <div class="h-full bg-gradient-to-r from-indigo-500 to-purple-500" style="width: <?php echo e(min(100, max(0, $pct))); ?>%"></div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="p-2.5">
                        <p class="text-xs sm:text-sm font-semibold leading-snug line-clamp-2 text-gray-100"><?php echo e($item->title); ?></p>
                        <?php if($item->year ?? null): ?>
                            <p class="text-[11px] text-gray-500 mt-0.5"><?php echo e($item->year); ?></p>
                        <?php endif; ?>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\components\carousel-row.blade.php ENDPATH**/ ?>