<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> <h1 class="text-lg font-semibold text-white">Articles</h1> <?php $__env->endSlot(); ?>

    <form method="GET" class="flex flex-wrap gap-2 mb-5">
        <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search title…"
               class="flex-1 min-w-0 bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2">
        <select name="status" class="bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2">
            <option value="">All Status</option>
            <option value="published" <?php echo e(request('status') === 'published' ? 'selected' : ''); ?>>Published</option>
            <option value="draft"     <?php echo e(request('status') === 'draft'     ? 'selected' : ''); ?>>Draft</option>
            <option value="trashed"   <?php echo e(request('status') === 'trashed'   ? 'selected' : ''); ?>>Trashed</option>
        </select>
        <button class="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm rounded-lg transition">Filter</button>
    </form>

    <div class="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        <table class="min-w-full divide-y divide-gray-800 text-sm">
            <thead class="bg-gray-800/50">
                <tr>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Title</th>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Author</th>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Status</th>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Featured</th>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Date</th>
                    <th class="px-5 py-3"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-800">
                <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-800/30 transition <?php echo e($article->trashed() ? 'opacity-50' : ''); ?>">
                    <td class="px-5 py-3 font-medium text-white max-w-xs truncate"><?php echo e($article->title); ?></td>
                    <td class="px-5 py-3 text-gray-400"><?php echo e($article->user->name); ?></td>
                    <td class="px-5 py-3">
                        <span class="px-2 py-0.5 text-xs rounded-full <?php echo e($article->trashed() ? 'bg-gray-700 text-gray-400' : ($article->isPublished() ? 'bg-green-500/20 text-green-300' : 'bg-yellow-500/20 text-yellow-300')); ?>">
                            <?php echo e($article->trashed() ? 'Trashed' : ucfirst($article->status)); ?>

                        </span>
                    </td>
                    <td class="px-5 py-3 text-gray-400"><?php echo e($article->is_featured ? '★' : '—'); ?></td>
                    <td class="px-5 py-3 text-gray-500"><?php echo e($article->created_at->format('d M Y')); ?></td>
                    <td class="px-5 py-3 text-right">
                        <div class="flex items-center justify-end gap-3">
                            <?php if($article->trashed()): ?>
                                <form method="POST" action="<?php echo e(route('admin.articles.restore', $article->id)); ?>"><?php echo csrf_field(); ?>
                                    <button class="text-green-400 hover:text-green-300 transition">Restore</button>
                                </form>
                            <?php else: ?>
                                <a href="<?php echo e(route('admin.articles.edit', $article)); ?>" class="text-indigo-400 hover:text-indigo-300 transition">Edit</a>
                                <form method="POST" action="<?php echo e(route('admin.articles.destroy', $article)); ?>" onsubmit="return confirm('Delete?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="text-red-400 hover:text-red-300 transition">Delete</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="px-5 py-10 text-center text-gray-500">No articles found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="px-5 py-4"><?php echo e($articles->links()); ?></div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\admin\articles\index.blade.php ENDPATH**/ ?>