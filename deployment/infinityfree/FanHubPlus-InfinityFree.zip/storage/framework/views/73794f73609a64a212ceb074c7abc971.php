<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
            <p class="text-xs font-semibold uppercase tracking-[.18em] text-violet-300">Community moderation</p>
            <h1 class="mt-1 text-2xl font-bold text-white">Review queue</h1>
            <p class="mt-1 text-sm text-gray-400">User reviews appear publicly only after approval. Star ratings remain saved independently.</p>
        </div>
        <span class="rounded-full border border-amber-400/20 bg-amber-400/10 px-3 py-1 text-sm font-semibold text-amber-200"><?php echo e($reviews->total()); ?> <?php echo e($status === 'all' ? 'reviews' : $status); ?></span>
    </div>

    <?php if(session('success')): ?>
        <div class="mb-4 rounded-lg border border-emerald-400/20 bg-emerald-400/10 px-4 py-3 text-sm text-emerald-200" role="status"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <nav class="mb-5 flex flex-wrap gap-2" aria-label="Review status filter">
        <?php $__currentLoopData = ['pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected', 'all' => 'All reviews']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('admin.reviews.index', ['status' => $key])); ?>" class="rounded-lg border px-4 py-2 text-sm font-medium transition <?php echo e($status === $key ? 'border-violet-400 bg-violet-500/15 text-violet-200' : 'border-gray-800 bg-gray-900 text-gray-400 hover:text-white'); ?>"><?php echo e($label); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>

    <div class="space-y-4">
        <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="rounded-xl border border-gray-800 bg-gray-900 p-5">
                <div class="flex flex-wrap items-start justify-between gap-3">
                    <div>
                        <h2 class="font-semibold text-white"><?php echo e($review->content?->title ?? 'Deleted content'); ?></h2>
                        <p class="mt-1 text-sm text-gray-400">By <?php echo e($review->user?->name ?? 'Deleted user'); ?>

                            <?php if($review->user?->email): ?> · <?php echo e($review->user->email); ?> <?php endif; ?>
                            · <?php echo e($review->created_at?->diffForHumans()); ?>

                        </p>
                    </div>
                    <span class="text-lg tracking-wide text-amber-300" aria-label="<?php echo e($review->rating); ?> out of 5 stars"><?php echo e(str_repeat('★', $review->rating)); ?><span class="text-gray-600"><?php echo e(str_repeat('★', 5 - $review->rating)); ?></span></span>
                </div>
                <p class="mt-4 whitespace-pre-line rounded-lg bg-gray-800/70 p-4 text-sm leading-relaxed text-gray-200"><?php echo e($review->review); ?></p>
                <?php if($review->admin_reaction || $review->admin_reply): ?>
                    <div class="mt-3 rounded-lg border border-violet-400/15 bg-violet-500/5 p-3 text-sm">
                        <p class="font-semibold text-violet-200">Current admin response<?php echo e($review->admin_reaction ? ' · ' . ucfirst($review->admin_reaction) : ''); ?></p>
                        <?php if($review->admin_reply): ?><p class="mt-1 whitespace-pre-line text-gray-300"><?php echo e($review->admin_reply); ?></p><?php endif; ?>
                    </div>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('admin.reviews.moderate', $review)); ?>" class="mt-4 space-y-3">
                    <?php echo csrf_field(); ?>
                    <label class="block text-xs font-medium text-gray-400" for="admin-reply-<?php echo e($review->id); ?>">Reply to the user (shown under their public review after approval)</label>
                    <textarea id="admin-reply-<?php echo e($review->id); ?>" name="admin_reply" maxlength="2000" rows="3" placeholder="Write a helpful response..." class="w-full rounded-lg border border-gray-700 bg-gray-800 px-3 py-2 text-sm text-white placeholder-gray-500"><?php echo e(old('admin_reply', $review->admin_reply)); ?></textarea>
                    <div class="flex flex-wrap items-center gap-2">
                        <label class="text-sm text-gray-300" for="admin-reaction-<?php echo e($review->id); ?>">Reaction</label>
                        <select id="admin-reaction-<?php echo e($review->id); ?>" name="admin_reaction" class="min-h-10 rounded-lg border border-gray-700 bg-gray-800 px-3 text-sm text-white">
                            <option value="">No reaction</option>
                            <option value="like" <?php if(old('admin_reaction', $review->admin_reaction) === 'like'): echo 'selected'; endif; ?>>Like</option>
                            <option value="heart" <?php if(old('admin_reaction', $review->admin_reaction) === 'heart'): echo 'selected'; endif; ?>>Heart</option>
                            <option value="thanks" <?php if(old('admin_reaction', $review->admin_reaction) === 'thanks'): echo 'selected'; endif; ?>>Thank you</option>
                        </select>
                        <input name="reason" maxlength="1000" placeholder="Optional rejection reason" value="<?php echo e(old('reason')); ?>" class="min-h-10 min-w-56 flex-1 rounded-lg border border-gray-700 bg-gray-800 px-3 text-sm text-white placeholder-gray-500">
                        <button name="decision" value="keep" class="min-h-10 rounded-lg bg-indigo-700 px-4 font-semibold text-white transition hover:bg-indigo-600">Save reply / reaction</button>
                        <?php if($review->review_status !== 'approved'): ?><button name="decision" value="approve" class="min-h-10 rounded-lg bg-emerald-700 px-4 font-semibold text-white transition hover:bg-emerald-600">Approve &amp; publish</button><?php endif; ?>
                        <?php if($review->review_status !== 'rejected'): ?><button name="decision" value="reject" class="min-h-10 rounded-lg bg-rose-900 px-4 font-semibold text-white transition hover:bg-rose-800">Reject</button><?php endif; ?>
                    </div>
                </form>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="rounded-xl border border-gray-800 bg-gray-900 p-8 text-center">
                <h2 class="font-semibold text-white">No <?php echo e($status === 'all' ? '' : $status); ?> reviews found</h2>
                <p class="mt-1 text-sm text-gray-400">Submitted reviews appear here for moderation and admin replies.</p>
            </div>
        <?php endif; ?>
    </div>

    <div class="mt-6"><?php echo e($reviews->links()); ?></div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\admin\reviews\index.blade.php ENDPATH**/ ?>