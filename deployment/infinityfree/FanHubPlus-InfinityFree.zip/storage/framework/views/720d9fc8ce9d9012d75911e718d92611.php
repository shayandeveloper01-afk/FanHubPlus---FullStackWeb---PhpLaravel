<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Explore — <?php echo e(config('app.name')); ?></title>
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600,700&display=swap" rel="stylesheet"/>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-950 text-white font-sans antialiased min-h-screen">


<?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main id="fh-main-content" class="fh-explore-page max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 py-6" tabindex="-1">

    <h1 class="text-2xl font-bold mb-6">Explore Content</h1>

    
    <form method="GET" action="<?php echo e(route('explore')); ?>" id="filter-form"
          x-data="{ open: false }">

        
        <div class="flex flex-col sm:flex-row gap-3 mb-4">
            
            <div class="relative flex-1">
                <svg class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400"
                     fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M21 21l-4.35-4.35M17 11A6 6 0 1 1 5 11a6 6 0 0 1 12 0z"/>
                </svg>
                <input type="text" name="q" value="<?php echo e($search); ?>" data-fh-search autocomplete="off"
                       placeholder="Search titles, descriptions…"
                       class="w-full bg-gray-800 border border-gray-700 text-white placeholder-gray-500
                              rounded-lg pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2
                              focus:ring-indigo-500 focus:border-transparent">
            </div>

            
            <select name="sort" onchange="document.getElementById('filter-form').submit()"
                    class="bg-gray-800 border border-gray-700 text-white rounded-lg px-4 py-2.5
                           text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 sm:w-44">
                <option value="newest" <?php echo e(in_array($sort, ['newest', 'latest']) ? 'selected' : ''); ?>>Newest</option>
                <option value="trending" <?php echo e(in_array($sort, ['trending', 'popular']) ? 'selected' : ''); ?>>Trending</option>
                <option value="rating" <?php echo e($sort === 'rating' ? 'selected' : ''); ?>>Top rated</option>
                <option value="views" <?php echo e($sort === 'views' ? 'selected' : ''); ?>>Most viewed</option>
            </select>

            
            <button type="button" @click="open = !open"
                    class="sm:hidden flex items-center gap-2 bg-gray-800 border border-gray-700
                           text-white rounded-lg px-4 py-2.5 text-sm">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M3 4h18M7 8h10M11 12h4"/>
                </svg>
                Filters
            </button>

            
            <button type="submit"
                    class="bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg px-5 py-2.5 text-sm font-medium transition">
                Search
            </button>
        </div>

        
        <div :class="open ? 'flex' : 'hidden sm:flex'" class="flex-wrap gap-3 mb-4">

            
            <select name="category" onchange="document.getElementById('filter-form').submit()"
                    class="bg-gray-800 border border-gray-700 text-white rounded-lg px-3 py-2
                           text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                <option value="">All Categories</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>" <?php echo e(($filters['category'] ?? '') == $cat->id ? 'selected' : ''); ?>>
                        <?php echo e($cat->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            
            <select name="genre" onchange="document.getElementById('filter-form').submit()"
                    class="bg-gray-800 border border-gray-700 text-white rounded-lg px-3 py-2
                           text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                <option value="">All Genres</option>
                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($g); ?>" <?php echo e(($filters['genre'] ?? '') === $g ? 'selected' : ''); ?>>
                        <?php echo e($g); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            
            <select name="year" onchange="document.getElementById('filter-form').submit()"
                    class="bg-gray-800 border border-gray-700 text-white rounded-lg px-3 py-2
                           text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                <option value="">All Years</option>
                <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($y); ?>" <?php echo e(($filters['year'] ?? '') == $y ? 'selected' : ''); ?>>
                        <?php echo e($y); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            
            <select name="type" onchange="document.getElementById('filter-form').submit()"
                    class="bg-gray-800 border border-gray-700 text-white rounded-lg px-3 py-2
                           text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                <option value="">All Types</option>
                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($t); ?>" <?php echo e(($filters['type'] ?? '') === $t ? 'selected' : ''); ?>>
                        <?php echo e(ucfirst($t)); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <label class="text-sm text-gray-400 flex items-center gap-2">Minimum rating
                <select name="min_rating" class="bg-gray-800 border border-gray-700 text-white rounded-lg px-3 py-2">
                    <option value="">Any</option>
                    <?php $__currentLoopData = [3, 4, 5]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($rating); ?>" <?php if(($filters['min_rating'] ?? '') == $rating): echo 'selected'; endif; ?>><?php echo e($rating); ?>+</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>

        </div>
    </form>

    
    <?php if(count($activeFilters) > 0): ?>
        <div class="flex flex-wrap gap-2 mb-5">
            <?php $__currentLoopData = $activeFilters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $label = match($key) {
                        'category' => 'Category: ' . ($categories->firstWhere('id', $value)?->name ?? $value),
                        'genre'    => 'Genre: ' . $value,
                        'year'     => 'Year: ' . $value,
                        'type'     => 'Type: ' . ucfirst($value),
                        'search'   => 'Search: "' . $value . '"',
                        'sort'     => 'Sort: ' . ucfirst($value),
                        default    => $key . ': ' . $value,
                    };
                    // Build URL without this filter
                    $remaining = array_filter(
                        array_merge($filters, ['search' => $search, 'sort' => $sort]),
                        fn($v, $k) => filled($v) && $k !== $key,
                        ARRAY_FILTER_USE_BOTH
                    );
                ?>
                <a href="<?php echo e(route('explore', $remaining)); ?>"
                   class="inline-flex items-center gap-1.5 bg-indigo-600/20 border border-indigo-500/40
                          text-indigo-300 text-xs px-3 py-1 rounded-full hover:bg-red-600/20
                          hover:border-red-500/40 hover:text-red-300 transition">
                    <?php echo e($label); ?>

                    <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('explore')); ?>"
               class="text-xs text-gray-500 hover:text-gray-300 px-2 py-1 transition">
                Clear all
            </a>
        </div>
    <?php endif; ?>

    
    <p class="text-sm text-gray-400 mb-5">
        <?php echo e($contents->total()); ?> <?php echo e(Str::plural('result', $contents->total())); ?> found
    </p>

    
    <?php if($contents->isEmpty()): ?>
        <div class="flex flex-col items-center justify-center py-24 text-center">
            <svg class="w-16 h-16 text-gray-700 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                      d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            <p class="text-gray-400 text-lg font-medium">No content found</p>
            <p class="text-gray-600 text-sm mt-1">Try adjusting your filters or search term.</p>
            <a href="<?php echo e(route('explore')); ?>" class="mt-4 text-indigo-400 hover:text-indigo-300 text-sm transition">
                Clear all filters
            </a>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal50451f1e0b04fb740cb30a32f53f5734 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal50451f1e0b04fb740cb30a32f53f5734 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.content-card','data' => ['content' => $content]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('content-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['content' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal50451f1e0b04fb740cb30a32f53f5734)): ?>
<?php $attributes = $__attributesOriginal50451f1e0b04fb740cb30a32f53f5734; ?>
<?php unset($__attributesOriginal50451f1e0b04fb740cb30a32f53f5734); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50451f1e0b04fb740cb30a32f53f5734)): ?>
<?php $component = $__componentOriginal50451f1e0b04fb740cb30a32f53f5734; ?>
<?php unset($__componentOriginal50451f1e0b04fb740cb30a32f53f5734); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div class="mt-10 dark-pagination">
            <?php echo e($contents->links()); ?>

        </div>
    <?php endif; ?>

</main>

<?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<script>
(() => {
    const input = document.querySelector('[data-fh-search]');
    if (!input) return;
    let timer;
    const list = document.createElement('div');
    list.className = 'fh-search-suggestions';
    list.setAttribute('role', 'listbox');
    input.parentElement.appendChild(list);
    input.addEventListener('input', () => {
        clearTimeout(timer);
        timer = setTimeout(async () => {
            const term = input.value.trim();
            if (!term) { list.replaceChildren(); return; }
            try {
                const response = await fetch(`<?php echo e(route('api.contents.search')); ?>?q=${encodeURIComponent(term)}`, { headers: { Accept: 'application/json' } });
                const results = await response.json();
                list.replaceChildren(...results.map((item) => {
                    const link = document.createElement('a');
                    link.className = 'fh-search-suggestion';
                    link.href = item.url;
                    link.textContent = item.title + (item.year ? ` (${item.year})` : '');
                    link.setAttribute('role', 'option');
                    return link;
                }));
            } catch (_) { list.replaceChildren(); }
        }, 300);
    });
    document.addEventListener('click', (event) => { if (!input.parentElement.contains(event.target)) list.replaceChildren(); });
})();
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views/explore/index.blade.php ENDPATH**/ ?>