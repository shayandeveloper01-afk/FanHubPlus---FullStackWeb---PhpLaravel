<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1 class="text-2xl font-bold text-white mb-6">Fan Resource Review</h1>
    <div class="space-y-4">
        <?php $__empty_1 = true; $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="bg-gray-900 border border-gray-800 rounded-xl p-5">
                <h2 class="text-white font-semibold"><?php echo e($resource->title); ?></h2>
                <p class="text-gray-400"><?php echo e($resource->type); ?> · <?php echo e($resource->user->name); ?> · <?php echo e($resource->file_size_kb); ?> KB</p>
                <?php if($resource->moderation_reason): ?><p class="text-red-300"><?php echo e($resource->moderation_reason); ?></p><?php endif; ?>
                <?php if (! ($resource->is_approved)): ?>
                    <form method="POST" action="<?php echo e(route('admin.resources.moderate', $resource)); ?>" class="mt-3 flex gap-2">
                        <?php echo csrf_field(); ?>
                        <button name="decision" value="approve" class="px-3 py-2 rounded bg-green-700 text-white">Approve</button>
                        <input name="reason" placeholder="Reason if rejecting" class="rounded bg-gray-800 text-white">
                        <button name="decision" value="reject" class="px-3 py-2 rounded bg-red-700 text-white">Reject</button>
                    </form>
                <?php endif; ?>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-gray-400">No submitted resources.</p>
        <?php endif; ?>
        <?php echo e($resources->links()); ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views/admin/resources/index.blade.php ENDPATH**/ ?>