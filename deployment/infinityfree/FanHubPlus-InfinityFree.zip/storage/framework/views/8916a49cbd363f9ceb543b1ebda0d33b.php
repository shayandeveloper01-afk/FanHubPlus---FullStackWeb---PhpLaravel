<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-2 text-sm text-gray-400">
            <a href="<?php echo e(route('admin.analytics.index')); ?>" class="hover:text-white transition">Analytics</a>
            <span>/</span>
            <span class="text-white">Feedback</span>
        </div>
     <?php $__env->endSlot(); ?>

    <?php $__env->startPush('head'); ?>
        <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <?php $__env->stopPush(); ?>

    
    <form method="GET" action="<?php echo e(route('admin.feedback.analytics')); ?>"
          class="flex flex-wrap items-end gap-3 mb-6">
        <input type="date" name="from" value="<?php echo e($from->toDateString()); ?>"
               class="bg-gray-800 border border-gray-700 text-white text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-indigo-500">
        <span class="text-gray-500 text-xs self-center">to</span>
        <input type="date" name="to" value="<?php echo e($to->toDateString()); ?>"
               class="bg-gray-800 border border-gray-700 text-white text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-indigo-500">

        <select name="type"
                class="bg-gray-800 border border-gray-700 text-white text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-indigo-500">
            <option value="">All Types</option>
            <?php $__currentLoopData = ['bug','suggestion','general','report']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($t); ?>" <?php echo e(request('type') === $t ? 'selected' : ''); ?>><?php echo e(ucfirst($t)); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <select name="status"
                class="bg-gray-800 border border-gray-700 text-white text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-indigo-500">
            <option value="">All Statuses</option>
            <?php $__currentLoopData = ['new','reviewed','resolved','dismissed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($s); ?>" <?php echo e(request('status') === $s ? 'selected' : ''); ?>><?php echo e(ucfirst($s)); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search subject / message…"
               class="bg-gray-800 border border-gray-700 text-white text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-indigo-500 w-52">

        <button type="submit"
                class="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs rounded-lg transition">
            Apply
        </button>
    </form>

    
    <div class="bg-gray-900 border border-gray-800 rounded-xl p-5 mb-6">
        <h2 class="text-sm font-semibold text-white mb-4">Category Breakdown Over Time</h2>
        <canvas id="chartFbBreakdown" height="120"></canvas>
    </div>

    
    <div class="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        <table class="min-w-full divide-y divide-gray-800 text-xs">
            <thead class="bg-gray-800/50">
                <tr>
                    <th class="px-4 py-3 text-left text-gray-400 font-medium uppercase">Ref</th>
                    <th class="px-4 py-3 text-left text-gray-400 font-medium uppercase">Subject</th>
                    <th class="px-4 py-3 text-left text-gray-400 font-medium uppercase">Type</th>
                    <th class="px-4 py-3 text-left text-gray-400 font-medium uppercase">Status</th>
                    <th class="px-4 py-3 text-left text-gray-400 font-medium uppercase">Submitted</th>
                    <th class="px-4 py-3 text-left text-gray-400 font-medium uppercase">Resolution</th>
                    <th class="px-4 py-3"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-800" id="feedbackTableBody">
                <?php $__empty_1 = true; $__currentLoopData = $feedback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-800/30 transition" id="fb-row-<?php echo e($fb->id); ?>">
                    <td class="px-4 py-3 text-gray-500 font-mono"><?php echo e($fb->reference_code ?? '—'); ?></td>
                    <td class="px-4 py-3 text-gray-300 max-w-xs truncate"><?php echo e($fb->subject); ?></td>
                    <td class="px-4 py-3">
                        <span class="px-2 py-0.5 rounded-full text-xs capitalize
                            <?php echo e(match($fb->type) {
                                'bug'        => 'bg-red-500/20 text-red-300',
                                'suggestion' => 'bg-blue-500/20 text-blue-300',
                                'report'     => 'bg-orange-500/20 text-orange-300',
                                default      => 'bg-gray-700 text-gray-400',
                            }); ?>">
                            <?php echo e($fb->type); ?>

                        </span>
                    </td>
                    <td class="px-4 py-3">
                        
                        <select data-fb-id="<?php echo e($fb->id); ?>"
                                class="status-select bg-gray-800 border border-gray-700 text-white text-xs rounded px-2 py-1 focus:outline-none focus:border-indigo-500">
                            <?php $__currentLoopData = ['new','reviewed','resolved','dismissed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s); ?>" <?php echo e($fb->status === $s ? 'selected' : ''); ?>><?php echo e(ucfirst($s)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                    <td class="px-4 py-3 text-gray-500"><?php echo e($fb->created_at->format('d M Y')); ?></td>
                    <td class="px-4 py-3 text-gray-500">
                        <?php if($fb->status === 'resolved'): ?>
                            <?php echo e(round($fb->created_at->diffInHours($fb->updated_at), 1)); ?>h
                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-3 text-right">
                        <a href="<?php echo e(route('admin.feedback.show', $fb)); ?>"
                           class="text-indigo-400 hover:text-indigo-300 transition">View</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="px-4 py-10 text-center text-gray-600">No feedback found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="px-4 py-4"><?php echo e($feedback->links()); ?></div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
    (function () {
        // ── Stacked bar: feedback by type per day ─────────────────────────────
        const raw = <?php echo json_encode($byTypePerDay); ?>;
        const days   = Object.keys(raw);
        const types  = ['bug', 'suggestion', 'general', 'report'];
        const colors = {
            bug:        'rgba(239,68,68,0.8)',
            suggestion: 'rgba(59,130,246,0.8)',
            general:    'rgba(107,114,128,0.8)',
            report:     'rgba(234,179,8,0.8)',
        };

        const datasets = types.map(type => ({
            label: type.charAt(0).toUpperCase() + type.slice(1),
            backgroundColor: colors[type],
            data: days.map(day => {
                const rows = raw[day] ?? [];
                const row  = rows.find(r => r.type === type);
                return row ? row.total : 0;
            }),
        }));

        new Chart(document.getElementById('chartFbBreakdown'), {
            type: 'bar',
            data: { labels: days, datasets },
            options: {
                scales: {
                    x: { stacked: true, ticks: { color: '#6b7280', font: { size: 10 }, maxTicksLimit: 10 },
                         grid: { color: 'rgba(255,255,255,0.05)' } },
                    y: { stacked: true, ticks: { color: '#6b7280', font: { size: 10 } },
                         grid: { color: 'rgba(255,255,255,0.05)' }, beginAtZero: true }
                },
                plugins: { legend: { labels: { color: '#9ca3af', font: { size: 10 } } } }
            }
        });

        // ── Inline status update via AJAX ─────────────────────────────────────
        const csrf = document.querySelector('meta[name="csrf-token"]')?.content;

        document.querySelectorAll('.status-select').forEach(sel => {
            sel.addEventListener('change', async function () {
                const id  = this.dataset.fbId;
                const val = this.value;
                try {
                    const res = await fetch(`/admin/feedback/${id}/status`, {
                        method:  'PATCH',
                        headers: {
                            'X-CSRF-TOKEN':  csrf,
                            'Content-Type':  'application/json',
                            'Accept':        'application/json',
                        },
                        body: JSON.stringify({ status: val }),
                    });
                    if (!res.ok) throw new Error();
                    // Flash the row green briefly
                    const row = document.getElementById(`fb-row-${id}`);
                    row.classList.add('bg-green-500/10');
                    setTimeout(() => row.classList.remove('bg-green-500/10'), 1200);
                } catch {
                    alert('Failed to update status.');
                }
            });
        });
    })();
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views/admin/analytics/feedback.blade.php ENDPATH**/ ?>