<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between"><h1 class="text-lg font-semibold text-white">Events</h1><a href="<?php echo e(route('admin.events.create')); ?>" class="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-500">Create Event</a></div>
     <?php $__env->endSlot(); ?>

    <form method="GET" class="flex flex-wrap gap-2 mb-5">
        <?php if(session('success')): ?><p class="w-full rounded-lg border border-emerald-500/30 bg-emerald-950/30 px-4 py-2 text-sm text-emerald-300" role="status"><?php echo e(session('success')); ?></p><?php endif; ?>
        <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search title…"
               class="flex-1 min-w-0 bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2">
        <select name="status" class="bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2">
            <option value="">All Status</option>
            <option value="trashed" <?php echo e(request('status') === 'trashed' ? 'selected' : ''); ?>>Trashed</option>
        </select>
        <button class="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm rounded-lg transition">Filter</button>
    </form>

    <div class="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        <table class="min-w-full divide-y divide-gray-800 text-sm">
            <thead class="bg-gray-800/50">
                <tr>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Title</th>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Author</th>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Start</th>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Status</th>
                    <th class="px-5 py-3"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-800">
                <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-800/30 transition <?php echo e($event->trashed() ? 'opacity-50' : ''); ?>">
                    <td class="px-5 py-3 font-medium text-white max-w-xs truncate"><?php echo e($event->title); ?></td>
                    <td class="px-5 py-3 text-gray-400"><?php echo e($event->user->name); ?></td>
                    <td class="px-5 py-3 text-gray-400"><?php echo e($event->start_datetime->format('d M Y')); ?></td>
                    <td class="px-5 py-3">
                        <?php if($event->trashed()): ?>
                            <span class="px-2 py-0.5 text-xs rounded-full bg-gray-700 text-gray-400">Trashed</span>
                        <?php else: ?>
                            <span class="px-2 py-0.5 text-xs rounded-full border <?php echo e($event->statusBadgeClass()); ?>"><?php echo e(ucfirst($event->status())); ?></span>
                        <?php endif; ?>
                    </td>
                    <td class="px-5 py-3 text-right">
                        <div class="flex items-center justify-end gap-3">
                            <?php if($event->trashed()): ?>
                                <form method="POST" action="<?php echo e(route('admin.events.restore', $event->id)); ?>"><?php echo csrf_field(); ?>
                                    <button class="text-green-400 hover:text-green-300 transition">Restore</button>
                                </form>
                            <?php else: ?>
                                <a href="<?php echo e(route('admin.events.edit', $event)); ?>" class="text-indigo-400 hover:text-indigo-300 transition">Edit</a>
                                <form method="POST" action="<?php echo e(route('admin.events.destroy', $event)); ?>" onsubmit="return confirm('Delete?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="text-red-400 hover:text-red-300 transition">Delete</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="px-5 py-10 text-center text-gray-500">No events found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="px-5 py-4"><?php echo e($events->links()); ?></div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views/admin/events/index.blade.php ENDPATH**/ ?>