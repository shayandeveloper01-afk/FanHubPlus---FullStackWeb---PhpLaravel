<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'src' => null,
    'title' => 'FanHub+ artwork',
    'category' => '',
    'kind' => 'content',
    'alt' => null,
    'class' => '',
    'loading' => 'lazy',
    'recordKey' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'src' => null,
    'title' => 'FanHub+ artwork',
    'category' => '',
    'kind' => 'content',
    'alt' => null,
    'class' => '',
    'loading' => 'lazy',
    'recordKey' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $fallback = \App\Support\ImageArtwork::fallbackSource($title, $category, $kind, $recordKey);
    // Callers normally pass the model resolver's result. Resolve here too when
    // a caller has no stored image so a title/category match can still reach
    // TMDB or Jikan before the SVG fallback.
    $resolved = $src ?: \App\Support\ImageArtwork::source(null, $title, $category, $kind, $recordKey);
?>
<img src="<?php echo e($resolved); ?>" alt="<?php echo e($alt ?? $title); ?>" class="<?php echo e($class); ?>" loading="<?php echo e($loading); ?>" decoding="async"
     onload="this.closest('.fh-skel')?.classList.remove('fh-skel')"
     onerror="this.onerror=null;this.src='<?php echo e($fallback); ?>'" <?php echo e($attributes); ?>>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus\resources\views/components/media-image.blade.php ENDPATH**/ ?>