<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-white leading-tight">
            Welcome back, <?php echo e(Auth::user()->name); ?> 👋
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">

            
            <?php
                $contentCount  = Auth::user()->contents()->count();
                $bookmarkCount = Auth::user()->bookmarks()->count();
                $articleCount  = Auth::user()->articles()->count();
                $ratingCount   = Auth::user()->ratings()->count();
            ?>
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div class="bg-gray-900 border border-gray-800 rounded-xl p-5 text-center">
                    <p class="text-3xl font-bold text-indigo-400"><?php echo e($contentCount); ?></p>
                    <p class="text-sm text-gray-400 mt-1">My Content</p>
                </div>
                <div class="bg-gray-900 border border-gray-800 rounded-xl p-5 text-center">
                    <p class="text-3xl font-bold text-indigo-400"><?php echo e($bookmarkCount); ?></p>
                    <p class="text-sm text-gray-400 mt-1">Bookmarks</p>
                </div>
                <div class="bg-gray-900 border border-gray-800 rounded-xl p-5 text-center">
                    <p class="text-3xl font-bold text-indigo-400"><?php echo e($articleCount); ?></p>
                    <p class="text-sm text-gray-400 mt-1">Articles</p>
                </div>
                <div class="bg-gray-900 border border-gray-800 rounded-xl p-5 text-center">
                    <p class="text-3xl font-bold text-indigo-400"><?php echo e($ratingCount); ?></p>
                    <p class="text-sm text-gray-400 mt-1">Ratings Given</p>
                </div>
            </div>

            
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <a href="<?php echo e(route('contents.create')); ?>"
                   class="flex items-center gap-4 bg-gray-900 border border-gray-800 hover:border-indigo-500/50 rounded-xl p-5 transition group">
                    <div class="w-10 h-10 bg-indigo-600/20 rounded-lg flex items-center justify-center group-hover:bg-indigo-600/40 transition">
                        <svg class="w-5 h-5 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                        </svg>
                    </div>
                    <div>
                        <p class="font-semibold text-white text-sm">New Content</p>
                        <p class="text-xs text-gray-500">Post a review or fan page</p>
                    </div>
                </a>
                <a href="<?php echo e(route('articles.create')); ?>"
                   class="flex items-center gap-4 bg-gray-900 border border-gray-800 hover:border-indigo-500/50 rounded-xl p-5 transition group">
                    <div class="w-10 h-10 bg-indigo-600/20 rounded-lg flex items-center justify-center group-hover:bg-indigo-600/40 transition">
                        <svg class="w-5 h-5 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                        </svg>
                    </div>
                    <div>
                        <p class="font-semibold text-white text-sm">Write Article</p>
                        <p class="text-xs text-gray-500">Rich-text with CKEditor</p>
                    </div>
                </a>
                <a href="<?php echo e(route('bookmarks.index')); ?>"
                   class="flex items-center gap-4 bg-gray-900 border border-gray-800 hover:border-indigo-500/50 rounded-xl p-5 transition group">
                    <div class="w-10 h-10 bg-indigo-600/20 rounded-lg flex items-center justify-center group-hover:bg-indigo-600/40 transition">
                        <svg class="w-5 h-5 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"/>
                        </svg>
                    </div>
                    <div>
                        <p class="font-semibold text-white text-sm">My Bookmarks</p>
                        <p class="text-xs text-gray-500"><?php echo e($bookmarkCount); ?> saved items</p>
                    </div>
                </a>
            </div>

            
            <?php if($contentCount > 0): ?>
            <div>
                <div class="flex items-center justify-between mb-4">
                    <h3 class="font-semibold text-white">Recent Content</h3>
                    <a href="<?php echo e(route('contents.index')); ?>" class="text-sm text-indigo-400 hover:text-indigo-300 transition">View all</a>
                </div>
                <div class="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
                    <table class="min-w-full divide-y divide-gray-800">
                        <tbody class="divide-y divide-gray-800">
                            <?php $__currentLoopData = Auth::user()->contents()->with('category')->latest()->limit(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-800/30 transition">
                                <td class="px-5 py-3">
                                    <a href="<?php echo e(route('contents.show', $content)); ?>">
                                        <?php if (isset($component)) { $__componentOriginal866276d147fd9806dc1448ec1d213bc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal866276d147fd9806dc1448ec1d213bc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.media-image','data' => ['src' => $content->thumbnailUrl(),'title' => $content->title,'category' => $content->category?->name ?? $content->type,'kind' => 'content','recordKey' => $content->id,'alt' => $content->title,'class' => 'w-10 h-14 object-cover rounded-md']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('media-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content->thumbnailUrl()),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content->title),'category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content->category?->name ?? $content->type),'kind' => 'content','record-key' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content->id),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content->title),'class' => 'w-10 h-14 object-cover rounded-md']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $attributes = $__attributesOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $component = $__componentOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__componentOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
                                    </a>
                                </td>
                                <td class="px-5 py-3">
                                    <a href="<?php echo e(route('contents.show', $content)); ?>"
                                       class="text-sm text-indigo-400 hover:text-indigo-300 font-medium transition">
                                        <?php echo e($content->title); ?>

                                    </a>
                                </td>
                                <td class="px-5 py-3 text-xs text-gray-500"><?php echo e($content->category->name); ?></td>
                                <td class="px-5 py-3">
                                    <span class="text-xs px-2 py-0.5 rounded-full
                                        <?php echo e($content->isPublished() ? 'bg-green-900/50 text-green-400' : 'bg-yellow-900/50 text-yellow-400'); ?>">
                                        <?php echo e(ucfirst($content->status)); ?>

                                    </span>
                                </td>
                                <td class="px-5 py-3 text-xs text-gray-600"><?php echo e($content->created_at->diffForHumans()); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus\resources\views/dashboard.blade.php ENDPATH**/ ?>