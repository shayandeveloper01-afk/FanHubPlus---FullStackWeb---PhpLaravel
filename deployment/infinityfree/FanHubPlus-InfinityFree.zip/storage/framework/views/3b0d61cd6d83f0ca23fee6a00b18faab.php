<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['crumbs' => []]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['crumbs' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $allCrumbs = array_merge(
        [['label' => 'Home', 'url' => route('home')]],
        $crumbs
    );
?>

<nav class="fh-breadcrumb" aria-label="Breadcrumb">
    <ol vocab="https://schema.org/" typeof="BreadcrumbList"
        style="list-style:none;display:flex;align-items:center;flex-wrap:wrap;gap:.25rem;margin:0;padding:0">
        <?php $__currentLoopData = $allCrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $crumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $isLast = $i === count($allCrumbs) - 1; ?>
            <li property="itemListElement" typeof="ListItem"
                style="display:flex;align-items:center;gap:.25rem">
                <?php if(!$isLast): ?>
                    <a href="<?php echo e($crumb['url']); ?>"
                       class="fh-breadcrumb__link"
                       property="item" typeof="WebPage">
                        <span property="name"><?php echo e($crumb['label']); ?></span>
                    </a>
                    <meta property="position" content="<?php echo e($i + 1); ?>">
                    <svg class="fh-breadcrumb__sep" width="12" height="12"
                         fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round"
                              stroke-width="2" d="M9 5l7 7-7 7"/>
                    </svg>
                <?php else: ?>
                    <span class="fh-breadcrumb__current"
                          property="name" aria-current="page"><?php echo e($crumb['label']); ?></span>
                    <meta property="position" content="<?php echo e($i + 1); ?>">
                    <?php if(!empty($crumb['url'])): ?>
                        <link property="item" href="<?php echo e($crumb['url']); ?>">
                    <?php endif; ?>
                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</nav>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\components\breadcrumb.blade.php ENDPATH**/ ?>