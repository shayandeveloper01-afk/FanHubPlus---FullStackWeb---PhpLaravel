<img src="<?php echo e(asset('images/fanhub-plus-logo.png')); ?>" alt="FanHub+"
     <?php echo e($attributes->merge(['class' => 'fh-logo-mark object-contain', 'role' => 'img', 'aria-label' => 'FanHub+'])); ?>>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views/components/fh-logo-mark.blade.php ENDPATH**/ ?>