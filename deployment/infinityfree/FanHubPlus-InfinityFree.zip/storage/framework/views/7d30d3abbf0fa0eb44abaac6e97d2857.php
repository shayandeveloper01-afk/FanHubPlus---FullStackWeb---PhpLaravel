<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="fh-category-page">
        <?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['crumbs' => [['label' => 'Home', 'url' => route('home')], ['label' => 'Categories']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['crumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['label' => 'Home', 'url' => route('home')], ['label' => 'Categories']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
        <div class="fh-category-page__intro">
            <span class="fh-category-page__eyebrow">Find your fandom</span>
            <h1>Explore categories</h1>
            <p>Browse stories and fan content from the communities you love.</p>
        </div>
        <div class="fh-category-grid">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('categories.show', $category->slug)); ?>" class="fh-category-card" style="--fh-category-color:<?php echo e($category->color ?: '#8b5cf6'); ?>">
                    <?php ($representativeContent = $category->contents->first()); ?>
                    <?php if (isset($component)) { $__componentOriginal866276d147fd9806dc1448ec1d213bc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal866276d147fd9806dc1448ec1d213bc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.media-image','data' => ['src' => $representativeContent?->thumbnailUrl(),'title' => $representativeContent?->title ?? $category->name,'category' => $category->name,'kind' => 'category','recordKey' => $category->id,'alt' => $category->name.' category artwork','class' => 'w-full h-full object-cover']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('media-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($representativeContent?->thumbnailUrl()),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($representativeContent?->title ?? $category->name),'category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category->name),'kind' => 'category','record-key' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category->id),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category->name.' category artwork'),'class' => 'w-full h-full object-cover']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $attributes = $__attributesOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $component = $__componentOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__componentOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
                    <span class="fh-category-card__label">Category</span>
                    <strong><?php echo e($category->name); ?></strong>
                    <small><?php echo e($category->description); ?></small>
                    <span class="fh-category-card__count"><?php echo e($category->contents_count); ?> <?php echo e(\Illuminate\Support\Str::plural('title', $category->contents_count)); ?></span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views/categories/index.blade.php ENDPATH**/ ?>