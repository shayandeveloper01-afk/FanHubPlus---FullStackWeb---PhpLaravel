<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'variant'    => 'default',   
    'title'      => null,
    'desc'       => null,
    'actionUrl'  => null,
    'actionText' => null,
    'icon'       => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'variant'    => 'default',   
    'title'      => null,
    'desc'       => null,
    'actionUrl'  => null,
    'actionText' => null,
    'icon'       => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $variants = [
        'default'   => ['icon' => '📭', 'title' => 'Nothing here yet',       'desc' => 'There\'s no content to show right now.'],
        'bookmarks' => ['icon' => '🔖', 'title' => 'No bookmarks yet',        'desc' => 'Save content you love and find it here later.'],
        'search'    => ['icon' => '🔍', 'title' => 'No results found',        'desc' => 'Try different keywords or browse all content.'],
        'error'     => ['icon' => '⚠️', 'title' => 'Something went wrong',    'desc' => 'We couldn\'t load this content. Please try again.'],
        'offline'   => ['icon' => '📡', 'title' => 'You\'re offline',         'desc' => 'Check your connection and refresh the page.'],
    ];
    $v = $variants[$variant] ?? $variants['default'];
    $displayIcon  = $icon  ?? $v['icon'];
    $displayTitle = $title ?? $v['title'];
    $displayDesc  = $desc  ?? $v['desc'];
?>

<div class="fh-empty" role="status" aria-label="<?php echo e($displayTitle); ?>">
    <div class="fh-empty__icon" aria-hidden="true"><?php echo e($displayIcon); ?></div>
    <p class="fh-empty__title"><?php echo e($displayTitle); ?></p>
    <p class="fh-empty__desc"><?php echo e($displayDesc); ?></p>

    <?php if($actionUrl && $actionText): ?>
        <a href="<?php echo e($actionUrl); ?>" class="fh-empty__action">
            <?php echo e($actionText); ?>

        </a>
    <?php endif; ?>

    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\components\fh-empty-state.blade.php ENDPATH**/ ?>