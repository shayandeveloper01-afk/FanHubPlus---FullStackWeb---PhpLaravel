<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('head'); ?>
        <title>Merchandise — <?php echo e(config('app.name')); ?></title>
    <?php $__env->stopPush(); ?>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">

        
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
            <div>
                <h1 class="text-2xl font-bold text-white">Merchandise</h1>
                <p class="text-gray-400 text-sm mt-1"><?php echo e($items->total()); ?> item<?php echo e($items->total() !== 1 ? 's' : ''); ?></p>
            </div>
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('merchandise.create')); ?>"
                   class="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-lg transition">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                    Add Merchandise
                </a>
            <?php endif; ?>
        </div>

        
        <form method="GET" action="<?php echo e(route('merchandise.index')); ?>"
              class="flex flex-wrap gap-3 mb-8 items-end">

            <div class="flex flex-col gap-1">
                <label class="text-xs text-gray-400 font-medium">Category</label>
                <select name="category" onchange="this.form.submit()"
                        class="bg-gray-800 border border-gray-700 text-gray-200 text-sm rounded-lg px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500">
                    <option value="">All Categories</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>" <?php if(($filters['category'] ?? '') == $cat->id): echo 'selected'; endif; ?>><?php echo e($cat->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="flex flex-col gap-1">
                <label class="text-xs text-gray-400 font-medium">Tag</label>
                <select name="tag" onchange="this.form.submit()"
                        class="bg-gray-800 border border-gray-700 text-gray-200 text-sm rounded-lg px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500">
                    <option value="">All Tags</option>
                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tag->id); ?>" <?php if(($filters['tag'] ?? '') == $tag->id): echo 'selected'; endif; ?>><?php echo e($tag->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="flex flex-col gap-1">
                <label class="text-xs text-gray-400 font-medium">Sort</label>
                <select name="sort" onchange="this.form.submit()"
                        class="bg-gray-800 border border-gray-700 text-gray-200 text-sm rounded-lg px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500">
                    <option value="latest"     <?php if($sort === 'latest'): echo 'selected'; endif; ?>>Latest</option>
                    <option value="popular"    <?php if($sort === 'popular'): echo 'selected'; endif; ?>>Most Viewed</option>
                    <option value="price_asc"  <?php if($sort === 'price_asc'): echo 'selected'; endif; ?>>Price: Low → High</option>
                    <option value="price_desc" <?php if($sort === 'price_desc'): echo 'selected'; endif; ?>>Price: High → Low</option>
                </select>
            </div>

            <?php if(count($activeFilters)): ?>
                <a href="<?php echo e(route('merchandise.index')); ?>"
                   class="self-end px-3 py-2 text-xs text-gray-400 hover:text-white border border-gray-700 rounded-lg transition">
                    Clear filters
                </a>
            <?php endif; ?>
        </form>

        
        <?php if(session('success')): ?>
            <div class="mb-6 px-4 py-3 bg-green-500/10 border border-green-500/30 text-green-300 rounded-lg text-sm">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        
        <?php if($items->isEmpty()): ?>
            <div class="text-center py-24 text-gray-500">
                <svg class="w-12 h-12 mx-auto mb-4 opacity-40" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10"/></svg>
                <p class="text-lg font-medium">No merchandise found</p>
                <p class="text-sm mt-1">Try adjusting your filters.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal83637917ffd1c92ef457c188c6fcc114 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal83637917ffd1c92ef457c188c6fcc114 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.merchandise-card','data' => ['item' => $item]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('merchandise-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['item' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal83637917ffd1c92ef457c188c6fcc114)): ?>
<?php $attributes = $__attributesOriginal83637917ffd1c92ef457c188c6fcc114; ?>
<?php unset($__attributesOriginal83637917ffd1c92ef457c188c6fcc114); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal83637917ffd1c92ef457c188c6fcc114)): ?>
<?php $component = $__componentOriginal83637917ffd1c92ef457c188c6fcc114; ?>
<?php unset($__componentOriginal83637917ffd1c92ef457c188c6fcc114); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="mt-8 dark-pagination">
                <?php echo e($items->links()); ?>

            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\merchandise\index.blade.php ENDPATH**/ ?>