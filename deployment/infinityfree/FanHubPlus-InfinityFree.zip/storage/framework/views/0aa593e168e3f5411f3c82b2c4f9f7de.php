<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('head'); ?>
        <title><?php echo e($merchandise->title); ?> — <?php echo e(config('app.name')); ?></title>
    <?php $__env->stopPush(); ?>

    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10">

        
        <a href="<?php echo e(route('merchandise.index')); ?>" class="inline-flex items-center gap-1 text-sm text-gray-400 hover:text-white mb-6 transition">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
            Back to Merchandise
        </a>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-10">

            
            <div x-data="{ active: '<?php echo e($merchandise->imageUrl()); ?>' }">
                
                <div class="aspect-square rounded-xl overflow-hidden bg-gray-800 border border-gray-700">
                    <img :src="active" alt="<?php echo e($merchandise->title); ?>"
                         x-on:error.once="$el.src='<?php echo e(\App\Support\ImageArtwork::fallbackSource($merchandise->title, $merchandise->category?->name ?? 'Merchandise', 'merchandise', $merchandise->id)); ?>'"
                         class="w-full h-full object-cover">
                </div>

                
                <?php if($merchandise->images->isNotEmpty()): ?>
                    <div class="flex gap-2 mt-3 flex-wrap">
                        
                        <button @click="active = '<?php echo e($merchandise->imageUrl()); ?>'"
                                class="w-16 h-16 rounded-lg overflow-hidden border-2 transition"
                                :class="active === '<?php echo e($merchandise->imageUrl()); ?>' ? 'border-indigo-500' : 'border-gray-700 hover:border-gray-500'">
                            <?php if (isset($component)) { $__componentOriginal866276d147fd9806dc1448ec1d213bc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal866276d147fd9806dc1448ec1d213bc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.media-image','data' => ['src' => $merchandise->imageUrl(),'title' => $merchandise->title,'category' => $merchandise->category?->name ?? 'Merchandise','kind' => 'merchandise','recordKey' => $merchandise->id,'alt' => $merchandise->title,'class' => 'w-full h-full object-cover']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('media-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($merchandise->imageUrl()),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($merchandise->title),'category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($merchandise->category?->name ?? 'Merchandise'),'kind' => 'merchandise','record-key' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($merchandise->id),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($merchandise->title),'class' => 'w-full h-full object-cover']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $attributes = $__attributesOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $component = $__componentOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__componentOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
                        </button>
                        <?php $__currentLoopData = $merchandise->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button @click="active = '<?php echo e($img->url()); ?>'"
                                    class="w-16 h-16 rounded-lg overflow-hidden border-2 transition"
                                    :class="active === '<?php echo e($img->url()); ?>' ? 'border-indigo-500' : 'border-gray-700 hover:border-gray-500'">
                                <?php if (isset($component)) { $__componentOriginal866276d147fd9806dc1448ec1d213bc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal866276d147fd9806dc1448ec1d213bc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.media-image','data' => ['src' => $img->url(),'title' => $merchandise->title,'category' => $merchandise->category?->name ?? 'Merchandise','kind' => 'merchandise','recordKey' => $img->id,'alt' => $merchandise->title.' gallery image','class' => 'w-full h-full object-cover']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('media-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($img->url()),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($merchandise->title),'category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($merchandise->category?->name ?? 'Merchandise'),'kind' => 'merchandise','record-key' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($img->id),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($merchandise->title.' gallery image'),'class' => 'w-full h-full object-cover']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $attributes = $__attributesOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $component = $__componentOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__componentOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
                            </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>

            
            <div class="flex flex-col gap-5">
                
                <?php if($merchandise->tags->isNotEmpty()): ?>
                    <div class="flex flex-wrap gap-2">
                        <?php $__currentLoopData = $merchandise->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="text-xs font-semibold px-3 py-1 rounded-full border <?php echo e($tag->badgeClass()); ?>">
                                <?php echo e($tag->name); ?>

                            </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <h1 class="text-2xl font-bold text-white leading-tight"><?php echo e($merchandise->title); ?></h1>

                <?php ($itemTypeLabel = ['digital_image' => 'Digital image / artwork', 'digital_video' => 'Digital video', 'physical' => 'Physical merchandise'][$merchandise->item_type ?? 'physical'] ?? 'Physical merchandise'); ?>
                <span class="inline-flex w-fit items-center gap-2 rounded-full border border-purple-400/25 bg-purple-500/10 px-3 py-1 text-xs font-semibold text-purple-200"><?php echo e($itemTypeLabel); ?></span>

                <div class="flex items-center gap-4">
                    <span class="text-3xl font-bold text-indigo-400"><?php echo e($merchandise->formattedPrice()); ?></span>
                    <span class="text-gray-500 text-sm flex items-center gap-1">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                        <?php echo e(number_format($merchandise->views_count)); ?> views
                    </span>
                </div>

                <?php if($merchandise->category): ?>
                    <p class="text-indigo-300 text-sm"><?php echo e($merchandise->category->name); ?></p>
                <?php endif; ?>

                <?php if($merchandise->description): ?>
                    <p class="text-gray-300 text-sm leading-relaxed"><?php echo e($merchandise->description); ?></p>
                <?php endif; ?>

                
                <?php ($whatsappDigits = preg_replace('/\D+/', '', (string) $merchandise->whatsapp_number)); ?>
                <?php if($merchandise->whatsapp_number || $merchandise->instagram_url || $merchandise->facebook_url || $merchandise->external_purchase_link): ?>
                    <div class="rounded-xl border border-purple-400/15 bg-slate-900/70 p-4">
                        <p class="mb-3 text-sm font-semibold text-white">Contact the seller to arrange payment and delivery</p>
                        <div class="flex flex-wrap gap-3">
                            <?php if($whatsappDigits): ?>
                                <a href="https://wa.me/<?php echo e($whatsappDigits); ?>?text=<?php echo e(rawurlencode('Hi, I am interested in '.$merchandise->title)); ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center justify-center gap-2 rounded-xl bg-green-600 px-5 py-3 font-semibold text-white transition hover:bg-green-500">WhatsApp seller</a>
                            <?php endif; ?>
                            <?php if($merchandise->instagram_url): ?>
                                <a href="<?php echo e($merchandise->instagram_url); ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center justify-center gap-2 rounded-xl bg-fuchsia-700 px-5 py-3 font-semibold text-white transition hover:bg-fuchsia-600">Instagram</a>
                            <?php endif; ?>
                            <?php if($merchandise->facebook_url): ?>
                                <a href="<?php echo e($merchandise->facebook_url); ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center justify-center gap-2 rounded-xl bg-blue-700 px-5 py-3 font-semibold text-white transition hover:bg-blue-600">Facebook / Social</a>
                            <?php endif; ?>
                            <?php if($merchandise->external_purchase_link): ?>
                                <a href="<?php echo e($merchandise->external_purchase_link); ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-3 font-semibold text-white transition hover:bg-indigo-500">Purchase / other link</a>
                            <?php endif; ?>
                        </div>
                        <p class="mt-3 text-xs text-gray-400">Payment and digital file delivery are arranged directly with the seller. FanHub+ does not process this payment.</p>
                    </div>
                <?php else: ?>
                    <div class="rounded-xl bg-gray-800 px-6 py-3 text-center text-sm font-semibold text-gray-400">Seller has not added contact or purchase links yet.</div>
                <?php endif; ?>

                

                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $merchandise)): ?>
                    <div class="flex gap-3 pt-2 border-t border-gray-700">
                        <a href="<?php echo e(route('merchandise.edit', $merchandise)); ?>"
                           class="px-4 py-2 text-sm bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition">
                            Edit
                        </a>
                        <form method="POST" action="<?php echo e(route('merchandise.destroy', $merchandise)); ?>"
                              onsubmit="return confirm('Delete this merchandise?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="px-4 py-2 text-sm bg-red-600/20 hover:bg-red-600/40 text-red-400 rounded-lg transition">
                                Delete
                            </button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views/merchandise/show.blade.php ENDPATH**/ ?>