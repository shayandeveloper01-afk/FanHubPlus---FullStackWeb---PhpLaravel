<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> <h1 class="text-lg font-semibold text-white">Users</h1> <?php $__env->endSlot(); ?>

    <div class="flex flex-wrap gap-3 mb-5">
        <form method="GET" class="flex gap-2 flex-1 min-w-0">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search name or email…"
                   class="flex-1 bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500">
            <select name="filter" class="bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2">
                <option value="">All</option>
                <option value="admin"   <?php echo e(request('filter') === 'admin'   ? 'selected' : ''); ?>>Admins</option>
                <option value="banned"  <?php echo e(request('filter') === 'banned'  ? 'selected' : ''); ?>>Banned</option>
                <option value="deleted" <?php echo e(request('filter') === 'deleted' ? 'selected' : ''); ?>>Deleted</option>
            </select>
            <button class="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm rounded-lg transition">Filter</button>
        </form>
    </div>

    <div class="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        <table class="min-w-full divide-y divide-gray-800 text-sm">
            <thead class="bg-gray-800/50">
                <tr>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">User</th>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Joined</th>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Status</th>
                    <th class="px-5 py-3"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-800">
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-800/30 transition <?php echo e($user->trashed() ? 'opacity-50' : ''); ?>">
                    <td class="px-5 py-3">
                        <div class="flex items-center gap-3">
                            <img src="<?php echo e($user->avatarUrl()); ?>" class="h-8 w-8 rounded-full object-cover">
                            <div>
                                <p class="font-medium text-white"><?php echo e($user->name); ?></p>
                                <p class="text-xs text-gray-500"><?php echo e($user->email); ?></p>
                            </div>
                        </div>
                    </td>
                    <td class="px-5 py-3 text-gray-400"><?php echo e($user->created_at->format('d M Y')); ?></td>
                    <td class="px-5 py-3">
                        <div class="flex flex-wrap gap-1">
                            <?php if($user->is_admin): ?>
                                <span class="px-2 py-0.5 text-xs rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">Admin</span>
                            <?php endif; ?>
                            <?php if($user->isBanned()): ?>
                                <span class="px-2 py-0.5 text-xs rounded-full bg-red-500/20 text-red-300 border border-red-500/40">Banned</span>
                            <?php endif; ?>
                            <?php if($user->trashed()): ?>
                                <span class="px-2 py-0.5 text-xs rounded-full bg-gray-700 text-gray-400 border border-gray-600">Deleted</span>
                            <?php endif; ?>
                            <?php if(!$user->is_admin && !$user->isBanned() && !$user->trashed()): ?>
                                <span class="px-2 py-0.5 text-xs rounded-full bg-green-500/20 text-green-300 border border-green-500/40">Active</span>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td class="px-5 py-3">
                        <div class="flex items-center justify-end gap-3 flex-wrap">
                            <a href="<?php echo e(route('admin.users.show', $user->id)); ?>" class="text-indigo-400 hover:text-indigo-300 transition">View</a>

                            <?php if($user->id !== auth()->id()): ?>
                                <?php if(!$user->trashed()): ?>
                                    <?php if($user->is_admin): ?>
                                        <form method="POST" action="<?php echo e(route('admin.users.demote', $user)); ?>"><?php echo csrf_field(); ?>
                                            <button class="text-yellow-400 hover:text-yellow-300 transition">Demote</button>
                                        </form>
                                    <?php else: ?>
                                        <form method="POST" action="<?php echo e(route('admin.users.promote', $user)); ?>"><?php echo csrf_field(); ?>
                                            <button class="text-green-400 hover:text-green-300 transition">Promote</button>
                                        </form>
                                    <?php endif; ?>

                                    <?php if(!$user->is_admin): ?>
                                        <?php if($user->isBanned()): ?>
                                            <form method="POST" action="<?php echo e(route('admin.users.unban', $user)); ?>"><?php echo csrf_field(); ?>
                                                <button class="text-blue-400 hover:text-blue-300 transition">Unban</button>
                                            </form>
                                        <?php else: ?>
                                            <form method="POST" action="<?php echo e(route('admin.users.ban', $user)); ?>"><?php echo csrf_field(); ?>
                                                <button class="text-orange-400 hover:text-orange-300 transition">Ban</button>
                                            </form>
                                        <?php endif; ?>

                                        <form method="POST" action="<?php echo e(route('admin.users.destroy', $user)); ?>"
                                              onsubmit="return confirm('Soft-delete this user?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button class="text-red-400 hover:text-red-300 transition">Delete</button>
                                        </form>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <form method="POST" action="<?php echo e(route('admin.users.restore', $user->id)); ?>"><?php echo csrf_field(); ?>
                                        <button class="text-green-400 hover:text-green-300 transition">Restore</button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="px-5 py-10 text-center text-gray-500">No users found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="px-5 py-4"><?php echo e($users->links()); ?></div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views/admin/users/index.blade.php ENDPATH**/ ?>