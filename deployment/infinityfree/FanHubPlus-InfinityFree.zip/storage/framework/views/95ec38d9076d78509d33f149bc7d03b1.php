<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-3"><a href="<?php echo e(route('admin.events.index')); ?>" class="text-gray-400 hover:text-white">← Events</a><span class="text-gray-600">/</span><h1 class="text-lg font-semibold text-white">Edit Event</h1></div>
     <?php $__env->endSlot(); ?>
    <div class="max-w-4xl">
        <?php if($errors->any()): ?>
            <div class="mb-5 rounded-xl border border-rose-500/30 bg-rose-950/30 px-4 py-3 text-sm text-rose-200" role="alert"><p class="font-semibold">Please review these event details.</p><ul class="mt-1 list-inside list-disc"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(route('admin.events.update', $event)); ?>" enctype="multipart/form-data" id="adminEventForm" class="fh-event-form-shell">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <?php echo $__env->make('events._form', ['event' => $event], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="flex gap-3 pt-5"><button type="submit" class="px-5 py-2 text-white rounded-lg">Update Event</button><a href="<?php echo e(route('admin.events.index')); ?>" class="px-5 py-2 bg-gray-800 text-gray-300 rounded-lg">Cancel</a></div>
        </form>
    </div>
    <?php $__env->startPush('scripts'); ?>
    <script>
    (() => { const form = document.getElementById('adminEventForm'); const file = document.getElementById('cover_image'); const preview = document.getElementById('cover_image_preview'); let url;
        form?.addEventListener('submit', () => { const button = form.querySelector('[type=submit]'); if (form.checkValidity() && !button.disabled) { button.disabled = true; button.textContent = 'Saving…'; } });
        file?.addEventListener('change', () => { if (url) URL.revokeObjectURL(url); const image = file.files?.[0]; if (!image) return; url = URL.createObjectURL(image); preview.src = url; preview.classList.add('is-visible'); });
    })();
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\admin\events\edit.blade.php ENDPATH**/ ?>