<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="fh-category-page max-w-5xl">
        <?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['crumbs' => [['label' => 'Home', 'url' => route('home')], ['label' => 'About']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['crumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['label' => 'Home', 'url' => route('home')], ['label' => 'About']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
        <header class="fh-category-page__intro">
            <span class="fh-category-page__eyebrow">About FanHub Plus</span>
            <h1>A home for every fandom.</h1>
            <p>FanHub Plus brings entertainment discovery and fan community tools together in one place.</p>
        </header>

        <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
            <article class="rounded-2xl border border-white/10 bg-white/[.03] p-6 sm:p-7">
                <span class="mb-4 grid h-11 w-11 place-items-center rounded-xl border border-violet-300/20 bg-violet-500/10 text-violet-200" aria-hidden="true">✦</span>
                <h2 class="text-lg font-bold text-white">Discover what you love</h2>
                <p class="mt-2 text-sm leading-6 text-gray-400">Explore anime, comics, cosplay, gaming, manga, movies, and TV series through the content shared on FanHub Plus.</p>
            </article>
            <article class="rounded-2xl border border-white/10 bg-white/[.03] p-6 sm:p-7">
                <span class="mb-4 grid h-11 w-11 place-items-center rounded-xl border border-fuchsia-300/20 bg-fuchsia-500/10 text-fuchsia-200" aria-hidden="true">⌁</span>
                <h2 class="text-lg font-bold text-white">Make it your own</h2>
                <p class="mt-2 text-sm leading-6 text-gray-400">Save titles to your bookmarks, rate content, follow events, and browse fan merchandise using the tools already available on the platform.</p>
            </article>
        </div>

        <div class="mt-6 flex flex-wrap gap-3">
            <a href="<?php echo e(route('explore')); ?>" class="fh-nav__btn fh-nav__btn--primary">Explore FanHub Plus</a>
            <a href="<?php echo e(route('feedback.create')); ?>" class="fh-nav__btn fh-nav__btn--ghost border border-white/10">Contact the team</a>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\about\index.blade.php ENDPATH**/ ?>