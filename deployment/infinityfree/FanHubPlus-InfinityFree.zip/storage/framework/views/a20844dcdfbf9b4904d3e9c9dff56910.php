<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['item']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['item']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<a href="<?php echo e(route('merchandise.show', $item)); ?>"
   class="group relative flex flex-col rounded-xl overflow-hidden bg-gray-800 border border-gray-700 shadow-lg transition-transform duration-200 hover:scale-[1.02] hover:shadow-2xl hover:border-indigo-500/50 focus:outline-none focus:ring-2 focus:ring-indigo-500">

    
    <div class="aspect-square w-full overflow-hidden bg-gray-700">
        <?php if (isset($component)) { $__componentOriginal866276d147fd9806dc1448ec1d213bc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal866276d147fd9806dc1448ec1d213bc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.media-image','data' => ['src' => $item->imageUrl(),'title' => $item->title,'category' => $item->category?->name ?? 'Merchandise','kind' => 'merchandise','recordKey' => $item->id,'alt' => $item->title,'class' => 'w-full h-full object-cover transition-opacity duration-200 group-hover:opacity-80']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('media-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->imageUrl()),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->title),'category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->category?->name ?? 'Merchandise'),'kind' => 'merchandise','record-key' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->id),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->title),'class' => 'w-full h-full object-cover transition-opacity duration-200 group-hover:opacity-80']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $attributes = $__attributesOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $component = $__componentOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__componentOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
    </div>

    
    <?php if($item->tags->isNotEmpty()): ?>
        <div class="absolute top-2 left-2 flex flex-wrap gap-1">
            <?php $__currentLoopData = $item->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="text-[10px] font-semibold px-2 py-0.5 rounded-full border <?php echo e($tag->badgeClass()); ?>">
                    <?php echo e($tag->name); ?>

                </span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    
    <div class="p-3 flex flex-col gap-1 flex-1">
        <p class="text-white text-sm font-semibold leading-tight line-clamp-2"><?php echo e($item->title); ?></p>
        <div class="flex items-center justify-between mt-auto pt-2">
            <span class="text-indigo-300 text-xs font-bold"><?php echo e($item->formattedPrice()); ?></span>
            <span class="text-gray-500 text-[10px] flex items-center gap-1">
                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                <?php echo e(number_format($item->views_count)); ?>

            </span>
        </div>
    </div>
</a>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\components\merchandise-card.blade.php ENDPATH**/ ?>