<?php if (isset($component)) { $__componentOriginald4229a89377c2562f78a156d82799631 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald4229a89377c2562f78a156d82799631 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.fh-logo-mark','data' => ['attributes' => $attributes]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('fh-logo-mark'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['attributes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($attributes)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald4229a89377c2562f78a156d82799631)): ?>
<?php $attributes = $__attributesOriginald4229a89377c2562f78a156d82799631; ?>
<?php unset($__attributesOriginald4229a89377c2562f78a156d82799631); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald4229a89377c2562f78a156d82799631)): ?>
<?php $component = $__componentOriginald4229a89377c2562f78a156d82799631; ?>
<?php unset($__componentOriginald4229a89377c2562f78a156d82799631); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\components\application-logo.blade.php ENDPATH**/ ?>