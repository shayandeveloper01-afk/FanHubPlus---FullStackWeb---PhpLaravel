<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'action',
    'method'      => 'DELETE',
    'title'       => 'Are you sure?',
    'msg'         => 'This action cannot be undone.',
    'type'        => 'danger',
    'confirmText' => 'Delete',
    'cancelText'  => 'Cancel',
    'class'       => '',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'action',
    'method'      => 'DELETE',
    'title'       => 'Are you sure?',
    'msg'         => 'This action cannot be undone.',
    'type'        => 'danger',
    'confirmText' => 'Delete',
    'cancelText'  => 'Cancel',
    'class'       => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<button
    type="button"
    class="<?php echo e($class); ?>"
    data-fh-confirm
    data-fh-confirm-title="<?php echo e($title); ?>"
    data-fh-confirm-msg="<?php echo e($msg); ?>"
    data-fh-confirm-type="<?php echo e($type); ?>"
    data-fh-confirm-ok="<?php echo e($confirmText); ?>"
    data-fh-confirm-action="<?php echo e($action); ?>"
    data-fh-confirm-method="<?php echo e($method); ?>"
    <?php echo e($attributes->except(['class', 'action', 'method', 'title'])); ?>

>
    <?php echo e($slot); ?>

</button>


<form id="fh-confirm-form-<?php echo e(md5($action)); ?>"
      action="<?php echo e($action); ?>"
      method="POST"
      style="display:none">
    <?php echo csrf_field(); ?>
    <?php echo method_field($method); ?>
</form>

<?php if (! $__env->hasRenderedOnce('e65d5054-e059-42e8-aeca-bde54a39d181')): $__env->markAsRenderedOnce('e65d5054-e059-42e8-aeca-bde54a39d181'); ?>
<?php $__env->startPush('scripts'); ?>
<script>
// Wire fh-confirm buttons that have a data-fh-confirm-action to their hidden forms
document.addEventListener('click', function (e) {
    const btn = e.target.closest('[data-fh-confirm][data-fh-confirm-action]');
    if (!btn) return;
    e.preventDefault();
    e.stopPropagation();

    window.FhConfirm && window.FhConfirm.show({
        title:       btn.dataset.fhConfirmTitle   || 'Are you sure?',
        msg:         btn.dataset.fhConfirmMsg      || '',
        type:        btn.dataset.fhConfirmType     || 'danger',
        confirmText: btn.dataset.fhConfirmOk       || 'Confirm',
    }).then(function (ok) {
        if (!ok) return;
        const formId = 'fh-confirm-form-' + btn.dataset.fhConfirmAction
            .split('').reduce(function(a,b){a=((a<<5)-a)+b.charCodeAt(0);return a&a},0)
            .toString(16).replace('-','');
        // Fallback: find form by action attribute
        const form = document.querySelector('form[action="' + btn.dataset.fhConfirmAction + '"]') ||
                     document.getElementById(formId);
        if (form) {
            window.FhTopBar && window.FhTopBar.start();
            form.submit();
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\components\fh-confirm.blade.php ENDPATH**/ ?>