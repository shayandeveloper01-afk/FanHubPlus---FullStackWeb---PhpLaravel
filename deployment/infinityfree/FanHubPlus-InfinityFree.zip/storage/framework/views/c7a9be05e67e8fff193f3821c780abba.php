<?php
    $isInList   = in_array($item->id, (array) $myListIds);
    $matchScore = $matchScores[$item->id] ?? null;
    $rank       = $rank ?? null;
    $thumbnail  = method_exists($item, 'thumbnailUrl')
                    ? $item->thumbnailUrl()
                    : (method_exists($item, 'coverImageUrl')
                        ? $item->coverImageUrl()
                        : \App\Support\ImageArtwork::source(null, $item->title, $item->category?->name ?? 'Events', 'event', $item->id));
?>

<a href="<?php echo e(route('contents.show', $item)); ?>" class="fh-card">
    <div class="fh-card__media">
        <?php if (isset($component)) { $__componentOriginal866276d147fd9806dc1448ec1d213bc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal866276d147fd9806dc1448ec1d213bc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.media-image','data' => ['src' => $thumbnail,'title' => $item->title,'category' => $item->category?->name ?? 'Events','kind' => 'event','recordKey' => $item->id,'alt' => $item->title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('media-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($thumbnail),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->title),'category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->category?->name ?? 'Events'),'kind' => 'event','record-key' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->id),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->title)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $attributes = $__attributesOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $component = $__componentOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__componentOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>

        <?php if($rank): ?>
            <span class="fh-card__rank"><?php echo e($rank); ?></span>
        <?php elseif($matchScore): ?>
            <span class="fh-card__badge"><?php echo e(round($matchScore * 100)); ?>% Match</span>
        <?php endif; ?>

        <button type="button"
                class="fh-card__add mylist-btn"
                data-content-id="<?php echo e($item->id); ?>"
                data-in-list="<?php echo e($isInList ? 'true' : 'false'); ?>"
                aria-label="<?php echo e($isInList ? 'Remove from My List' : 'Add to My List'); ?>">
            <svg class="mylist-icon-add <?php echo e($isInList ? 'hidden' : ''); ?>"
                 fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 4v16m8-8H4"/>
            </svg>
            <svg class="mylist-icon-check <?php echo e($isInList ? '' : 'hidden'); ?>"
                 fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/>
            </svg>
        </button>

        <?php if(isset($progress) && $progress): ?>
            <div class="fh-card__progress">
                <span style="width: <?php echo e($progress); ?>%"></span>
            </div>
        <?php endif; ?>
    </div>

    <div class="fh-card__body">
        <h3 class="fh-card__title"><?php echo e($item->title); ?></h3>
        <div class="fh-card__meta">
            <?php if(!empty($item->release_year)): ?>
                <span><?php echo e($item->release_year); ?></span>
                <span class="fh-card__dot"></span>
            <?php endif; ?>
            <?php if($item->category): ?>
                <span><?php echo e($item->category->name); ?></span>
            <?php endif; ?>
        </div>
    </div>
</a>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\components\event-card.blade.php ENDPATH**/ ?>