<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($article->title); ?> — <?php echo e(config('app.name')); ?></title>

    
    <meta property="og:title"       content="<?php echo e($article->title); ?>">
    <meta property="og:description" content="<?php echo e($article->excerpt ?? Str::limit(strip_tags($article->body), 160)); ?>">
    <meta property="og:image"       content="<?php echo e($article->coverImageUrl()); ?>">
    <meta property="og:url"         content="<?php echo e(url()->current()); ?>">
    <meta property="og:type"        content="article">
    <meta name="twitter:card"       content="summary_large_image">

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600,700&display=swap" rel="stylesheet"/>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-950 text-white font-sans antialiased">

<?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="relative h-64 sm:h-96 overflow-hidden">
    <?php if (isset($component)) { $__componentOriginal866276d147fd9806dc1448ec1d213bc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal866276d147fd9806dc1448ec1d213bc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.media-image','data' => ['src' => $article->coverImageUrl(),'title' => $article->title,'category' => $article->category?->name ?? 'Editorial','kind' => 'article','recordKey' => $article->id,'alt' => $article->title,'class' => 'w-full h-full object-cover opacity-50']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('media-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($article->coverImageUrl()),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($article->title),'category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($article->category?->name ?? 'Editorial'),'kind' => 'article','record-key' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($article->id),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($article->title),'class' => 'w-full h-full object-cover opacity-50']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $attributes = $__attributesOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $component = $__componentOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__componentOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
    <div class="absolute inset-0 bg-gradient-to-t from-gray-950 via-gray-950/50 to-transparent"></div>
</div>

<div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">

    <div class="mb-6">
        <?php if($article->is_featured): ?>
            <span class="inline-block text-xs bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 px-2 py-0.5 rounded-full mb-3">
                ★ Featured
            </span>
        <?php endif; ?>
        <h1 class="text-3xl sm:text-4xl font-bold leading-tight mb-3"><?php echo e($article->title); ?></h1>
        <?php if($article->excerpt): ?>
            <p class="text-gray-400 text-lg leading-relaxed mb-4"><?php echo e($article->excerpt); ?></p>
        <?php endif; ?>
        <div class="flex items-center gap-3 text-sm text-gray-500">
            <span>by <?php echo e($article->user->name); ?></span>
            <span>· <?php echo e($article->read_time_minutes); ?> min read</span>
            <?php if($article->published_at): ?>
                <span>· <?php echo e($article->published_at->format('d M Y')); ?></span>
            <?php endif; ?>
        </div>
    </div>

    <div class="prose prose-invert prose-sm sm:prose max-w-none">
        <?php echo $article->body; ?>

    </div>

    
    <div class="mt-10 pt-6 border-t border-gray-800">
        <p class="text-xs text-gray-500 uppercase tracking-widest mb-3">Share this article</p>
        <?php $shareUrl = urlencode(url()->current()); $shareTitle = urlencode($article->title); ?>
        <div class="flex gap-2 flex-wrap">
            <a href="https://twitter.com/intent/tweet?url=<?php echo e($shareUrl); ?>&text=<?php echo e($shareTitle); ?>"
               target="_blank" rel="noopener"
               class="text-xs bg-gray-800 hover:bg-sky-600 border border-gray-700 px-3 py-1.5 rounded-lg transition">
                Share on X
            </a>
            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($shareUrl); ?>"
               target="_blank" rel="noopener"
               class="text-xs bg-gray-800 hover:bg-blue-600 border border-gray-700 px-3 py-1.5 rounded-lg transition">
                Share on Facebook
            </a>
            <button onclick="navigator.clipboard.writeText('<?php echo e(url()->current()); ?>').then(() => alert('Link copied!'))"
                    class="text-xs bg-gray-800 hover:bg-gray-700 border border-gray-700 px-3 py-1.5 rounded-lg transition">
                Copy Link
            </button>
        </div>
    </div>

</div>



<?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views/articles/show.blade.php ENDPATH**/ ?>