<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('head'); ?>
        <title>Edit Merchandise — <?php echo e(config('app.name')); ?></title>
    <?php $__env->stopPush(); ?>

    <div class="fh-merch-editor max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <a href="<?php echo e(route('merchandise.show', $merchandise)); ?>" class="fh-merch-editor__back inline-flex items-center gap-1 text-sm text-gray-400 hover:text-white mb-6 transition">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
            Back
        </a>

        <header class="fh-merch-editor__hero">
            <span class="fh-merch-editor__eyebrow">FanHub+ Marketplace <i></i> Creator studio</span>
            <h1 class="fh-merch-editor__title">Edit Merchandise</h1>
            <p class="fh-merch-editor__description">Refresh your listing details and imagery while keeping your existing product page intact.</p>
            <div class="fh-merch-editor__meta"><span>✦ Listing editor</span><span>◈ Update gallery</span></div>
        </header>

        <form method="POST" action="<?php echo e(route('merchandise.update', $merchandise)); ?>" enctype="multipart/form-data"
              class="fh-merch-form space-y-6">
            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>

            <?php echo $__env->make('merchandise._form', ['merchandise' => $merchandise], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            
            <?php if($merchandise->images->isNotEmpty()): ?>
                <section class="fh-merch-form__panel fh-merch-form__panel--current">
                    <div class="fh-merch-form__section-head"><span class="fh-merch-form__section-icon" aria-hidden="true">◈</span><div><h2>Current gallery</h2><p>Remove an image with its corner control.</p></div></div>
                    <div class="flex flex-wrap gap-3">
                        <?php $__currentLoopData = $merchandise->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="relative group">
                                <?php if (isset($component)) { $__componentOriginal866276d147fd9806dc1448ec1d213bc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal866276d147fd9806dc1448ec1d213bc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.media-image','data' => ['src' => $img->url(),'title' => $merchandise->title,'category' => $merchandise->category?->name ?? 'Merchandise','kind' => 'merchandise','recordKey' => $img->id,'alt' => $merchandise->title.' gallery image','class' => 'w-20 h-20 object-cover rounded-lg border border-gray-700']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('media-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($img->url()),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($merchandise->title),'category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($merchandise->category?->name ?? 'Merchandise'),'kind' => 'merchandise','record-key' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($img->id),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($merchandise->title.' gallery image'),'class' => 'w-20 h-20 object-cover rounded-lg border border-gray-700']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $attributes = $__attributesOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $component = $__componentOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__componentOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
                                <form method="POST"
                                      action="<?php echo e(route('merchandise.images.destroy', [$merchandise, $img])); ?>"
                                      onsubmit="return confirm('Remove this image?')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="absolute -top-2 -right-2 w-5 h-5 bg-red-600 rounded-full text-white text-xs flex items-center justify-center opacity-0 group-hover:opacity-100 transition">×</button>
                                </form>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </section>
            <?php endif; ?>

            <div class="fh-merch-form__actions flex gap-3 pt-2">
                <button type="submit"
                        class="fh-merch-submit px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg transition">
                    Save Changes
                </button>
                <a href="<?php echo e(route('merchandise.show', $merchandise)); ?>"
                   class="fh-merch-cancel px-6 py-2.5 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition">
                    Cancel
                </a>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\merchandise\edit.blade.php ENDPATH**/ ?>