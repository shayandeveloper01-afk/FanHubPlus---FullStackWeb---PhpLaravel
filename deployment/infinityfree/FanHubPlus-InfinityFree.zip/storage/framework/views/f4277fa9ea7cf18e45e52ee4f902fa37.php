<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['content', 'bookmarked' => null, 'class' => '', 'showLabel' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['content', 'bookmarked' => null, 'class' => '', 'showLabel' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if(auth()->guard()->check()): ?>
    <?php ($isBookmarked = $bookmarked ?? auth()->user()->bookmarks->contains('content_id', $content->id)); ?>
    <button type="button" class="bookmark-toggle <?php echo e($class); ?>"
            data-content-id="<?php echo e($content->id); ?>" data-bookmark-url="<?php echo e(route('bookmarks.toggle', $content)); ?>"
            data-bookmarked="<?php echo e($isBookmarked ? 'true' : 'false'); ?>"
            aria-label="<?php echo e($isBookmarked ? 'Remove bookmark' : 'Save bookmark'); ?>"
            aria-pressed="<?php echo e($isBookmarked ? 'true' : 'false'); ?>" title="<?php echo e($isBookmarked ? 'Remove bookmark' : 'Save to bookmarks'); ?>">
        <svg class="bookmark-icon h-4 w-4 shrink-0" fill="<?php echo e($isBookmarked ? 'currentColor' : 'none'); ?>" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"/>
        </svg>
        <?php if($showLabel): ?>
            <span class="bookmark-label"><?php echo e($isBookmarked ? 'Saved' : 'Bookmark'); ?></span>
        <?php endif; ?>
    </button>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\components\bookmark-button.blade.php ENDPATH**/ ?>