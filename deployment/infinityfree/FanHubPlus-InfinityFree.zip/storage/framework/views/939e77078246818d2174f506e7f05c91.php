<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h1 class="text-lg font-semibold text-white">Activity Log</h1>
     <?php $__env->endSlot(); ?>

    
    <form method="GET" class="flex flex-wrap gap-2 mb-5">
        <select name="admin_id"
                class="bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500">
            <option value="">All Admins</option>
            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($admin->id); ?>" <?php echo e(request('admin_id') == $admin->id ? 'selected' : ''); ?>>
                    <?php echo e($admin->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <input type="text" name="action" value="<?php echo e(request('action')); ?>" placeholder="Action (e.g. user.ban)…"
               class="bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500 w-48">

        <input type="date" name="from" value="<?php echo e(request('from')); ?>"
               class="bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500">
        <span class="text-gray-500 text-sm self-center">to</span>
        <input type="date" name="to" value="<?php echo e(request('to')); ?>"
               class="bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-indigo-500">

        <button class="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm rounded-lg transition">
            Filter
        </button>
        <?php if(request()->hasAny(['admin_id','action','from','to'])): ?>
            <a href="<?php echo e(route('admin.activity-log.index')); ?>"
               class="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white text-sm rounded-lg transition">
                Clear
            </a>
        <?php endif; ?>
    </form>

    <div class="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        <table class="min-w-full divide-y divide-gray-800 text-sm">
            <thead class="bg-gray-800/50">
                <tr>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">When</th>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Admin</th>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Action</th>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Target</th>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Notes</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-800">
                <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-800/30 transition">
                    <td class="px-5 py-3 text-gray-500 whitespace-nowrap">
                        <?php echo e($log->created_at->format('d M Y, h:i A')); ?>

                    </td>
                    <td class="px-5 py-3 text-gray-300"><?php echo e($log->admin?->name ?? '—'); ?></td>
                    <td class="px-5 py-3">
                        <span class="font-mono text-xs px-2 py-0.5 rounded
                            <?php echo e(str_starts_with($log->action, 'user.')     ? 'bg-indigo-500/20 text-indigo-300' :
                              (str_starts_with($log->action, 'content.')  ? 'bg-blue-500/20 text-blue-300'   :
                              (str_starts_with($log->action, 'event.')    ? 'bg-green-500/20 text-green-300' :
                              (str_starts_with($log->action, 'settings.') ? 'bg-yellow-500/20 text-yellow-300' :
                               'bg-gray-700 text-gray-400')))); ?>">
                            <?php echo e($log->action); ?>

                        </span>
                    </td>
                    <td class="px-5 py-3 text-gray-500 text-xs">
                        <?php if($log->target_type && $log->target_id): ?>
                            <?php echo e($log->target_type); ?> #<?php echo e($log->target_id); ?>

                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </td>
                    <td class="px-5 py-3 text-gray-400 max-w-xs truncate"><?php echo e($log->notes ?? '—'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="px-5 py-10 text-center text-gray-500">No activity logged yet.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="px-5 py-4"><?php echo e($logs->links()); ?></div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views/admin/activity-log/index.blade.php ENDPATH**/ ?>