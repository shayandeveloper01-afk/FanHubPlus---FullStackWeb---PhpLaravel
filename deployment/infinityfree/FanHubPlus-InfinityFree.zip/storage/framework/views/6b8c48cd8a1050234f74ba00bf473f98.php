<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="mx-auto max-w-5xl px-4 py-10 sm:px-6">
        <header class="mb-6">
            <p class="text-xs font-semibold uppercase tracking-[.18em] text-violet-300">Your account</p>
            <h1 class="mt-1 text-3xl font-bold text-white">My messages</h1>
            <p class="mt-2 text-sm text-gray-400">Contact messages, their status, and replies from the FanHub team.</p>
        </header>

        <div class="space-y-4">
            <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="rounded-xl border border-gray-800 bg-gray-900 p-5">
                    <div class="flex flex-wrap items-start justify-between gap-3">
                        <div>
                            <h2 class="font-semibold text-white"><?php echo e($message->subject); ?></h2>
                            <p class="mt-1 text-xs text-gray-500">Ref: <span class="font-mono text-violet-300"><?php echo e($message->reference_code); ?></span> · <?php echo e($message->created_at?->format('M j, Y')); ?></p>
                        </div>
                        <span class="rounded-full border px-2.5 py-1 text-xs <?php echo e($message->statusBadgeClass()); ?>"><?php echo e($message->statusLabel()); ?></span>
                    </div>
                    <p class="mt-3 whitespace-pre-line text-sm text-gray-300"><?php echo e($message->message); ?></p>
                    <?php if($message->admin_notes || $message->admin_reaction): ?>
                        <div class="mt-4 rounded-lg border border-violet-400/15 bg-violet-500/5 p-4">
                            <p class="text-xs font-semibold uppercase tracking-wide text-violet-200">Reply from the FanHub team</p>
                            <?php if($message->admin_notes): ?><p class="mt-2 whitespace-pre-line text-sm text-gray-200"><?php echo e($message->admin_notes); ?></p><?php endif; ?>
                            <?php if($message->admin_reaction): ?><p class="mt-2 text-xs font-semibold text-violet-300">Reaction: <?php echo e(ucfirst($message->admin_reaction)); ?></p><?php endif; ?>
                        </div>
                    <?php else: ?>
                        <p class="mt-3 text-xs text-gray-500">The team has not replied yet.</p>
                    <?php endif; ?>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="rounded-xl border border-gray-800 bg-gray-900 p-8 text-center">
                    <h2 class="font-semibold text-white">No messages yet</h2>
                    <p class="mt-1 text-sm text-gray-400">Messages you send while signed in will appear here.</p>
                    <a href="<?php echo e(route('feedback.create')); ?>" class="mt-4 inline-flex rounded-lg bg-indigo-600 px-5 py-2.5 font-semibold text-white hover:bg-indigo-500">Contact the team</a>
                </div>
            <?php endif; ?>
        </div>
        <div class="mt-6"><?php echo e($messages->links()); ?></div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\feedback\mine.blade.php ENDPATH**/ ?>