<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h1 class="text-lg font-semibold text-white">Feedback</h1>
     <?php $__env->endSlot(); ?>

    
    <?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['crumbs' => [['label' => 'Feedback']],'class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['crumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['label' => 'Feedback']]),'class' => 'mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>

    <form method="GET" class="flex flex-wrap gap-3 mb-5">
        <select name="type" onchange="this.form.submit()"
                class="bg-gray-800 border border-gray-700 text-sm text-white rounded-lg px-3 py-2">
            <option value="">All Types</option>
            <option value="bug"        <?php echo e(request('type') === 'bug'        ? 'selected' : ''); ?>>Bug</option>
            <option value="suggestion" <?php echo e(request('type') === 'suggestion' ? 'selected' : ''); ?>>Suggestion</option>
            <option value="general"    <?php echo e(request('type') === 'general'    ? 'selected' : ''); ?>>General</option>
            <option value="report"     <?php echo e(request('type') === 'report'     ? 'selected' : ''); ?>>Report</option>
        </select>
        <select name="status" onchange="this.form.submit()"
                class="bg-gray-800 border border-gray-700 text-sm text-white rounded-lg px-3 py-2">
            <option value="">All Statuses</option>
            <option value="new"       <?php echo e(request('status') === 'new'       ? 'selected' : ''); ?>>Pending</option>
            <option value="reviewed"  <?php echo e(request('status') === 'reviewed'  ? 'selected' : ''); ?>>In Review</option>
            <option value="resolved"  <?php echo e(request('status') === 'resolved'  ? 'selected' : ''); ?>>Resolved</option>
            <option value="dismissed" <?php echo e(request('status') === 'dismissed' ? 'selected' : ''); ?>>Dismissed</option>
        </select>
    </form>

    <div class="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        <table class="min-w-full divide-y divide-gray-800 text-sm">
            <thead class="bg-gray-800/50">
                <tr>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Ref</th>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">From</th>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Subject</th>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Type</th>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Status</th>
                    <th class="px-5 py-3 text-left text-xs font-medium text-gray-400 uppercase">Date</th>
                    <th class="px-5 py-3"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-800">
                <?php $__empty_1 = true; $__currentLoopData = $feedback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-800/30 transition">
                    <td class="px-5 py-3 font-mono text-xs text-indigo-400"><?php echo e($item->reference_code); ?></td>
                    <td class="px-5 py-3 text-gray-300 max-w-[140px] truncate">
                        <?php echo e($item->user?->name ?? $item->name ?? '—'); ?>

                        <?php if($item->email): ?>
                            <span class="block text-xs text-gray-500 truncate"><?php echo e($item->email); ?></span>
                        <?php endif; ?>
                    </td>
                    <td class="px-5 py-3 text-white max-w-xs truncate"><?php echo e($item->subject); ?></td>
                    <td class="px-5 py-3">
                        <span class="px-2 py-0.5 text-xs rounded-full border <?php echo e($item->typeBadgeClass()); ?>">
                            <?php echo e(ucfirst($item->type)); ?>

                        </span>
                    </td>
                    <td class="px-5 py-3">
                        <span class="px-2 py-0.5 text-xs rounded-full border <?php echo e($item->statusBadgeClass()); ?>">
                            <?php echo e($item->statusLabel()); ?>

                        </span>
                    </td>
                    <td class="px-5 py-3 text-gray-500 text-xs whitespace-nowrap"><?php echo e($item->created_at->format('M j, Y')); ?></td>
                    <td class="px-5 py-3 text-right">
                        <div class="flex items-center justify-end gap-3">
                            <a href="<?php echo e(route('admin.feedback.show', $item)); ?>" class="text-indigo-400 hover:text-indigo-300 transition">View</a>
                            <form method="POST" action="<?php echo e(route('admin.feedback.destroy', $item)); ?>" onsubmit="return confirm('Delete?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="text-red-400 hover:text-red-300 transition">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="px-5 py-10 text-center text-gray-500">No feedback found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="px-5 py-4"><?php echo e($feedback->links()); ?></div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\admin\feedback\index.blade.php ENDPATH**/ ?>