<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'content',
    'rank'       => null,
    'isNew'      => false,
    'matchPct'   => null,
    'progress'   => null,
    'inList'     => false,
    'bookmarked' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'content',
    'rank'       => null,
    'isNew'      => false,
    'matchPct'   => null,
    'progress'   => null,
    'inList'     => false,
    'bookmarked' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $poster = $content->thumbnailUrl();
    $typeLabel = match (strtolower((string) $content->type)) {
        'movie', 'film' => 'Film',
        'series', 'tv', 'television' => 'TV',
        'anime' => 'Anime',
        'game', 'gaming' => 'Gaming',
        'music' => 'Music',
        'podcast' => 'Podcast',
        default => $content->category?->name ?? Str::headline((string) $content->type),
    };
?>

<article class="fh-content-card group" data-content-id="<?php echo e($content->id); ?>">
    <a href="<?php echo e(route('contents.show', $content)); ?>" class="fh-content-card__link" data-content-id="<?php echo e($content->id); ?>" <?php if(!empty($content->trailer_url)): ?> data-trailer="<?php echo e($content->trailer_url); ?>" <?php endif; ?>>
        <div class="fh-content-card__media">
            <?php if (isset($component)) { $__componentOriginal866276d147fd9806dc1448ec1d213bc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal866276d147fd9806dc1448ec1d213bc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.media-image','data' => ['src' => $poster,'title' => $content->title,'category' => $content->category?->name ?? $content->type,'kind' => 'content','recordKey' => $content->id,'alt' => $content->title.' poster','class' => 'w-full h-full object-cover']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('media-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($poster),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content->title),'category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content->category?->name ?? $content->type),'kind' => 'content','record-key' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content->id),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content->title.' poster'),'class' => 'w-full h-full object-cover']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $attributes = $__attributesOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $component = $__componentOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__componentOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>

            <?php if($isNew): ?>
                <span class="fh-content-card__badge fh-content-card__badge--new">NEW</span>
            <?php elseif($matchPct !== null): ?>
                <span class="fh-content-card__badge fh-content-card__badge--match"><?php echo e(round($matchPct * 100)); ?>% Match</span>
            <?php endif; ?>

            <?php if($rank !== null): ?>
                <span class="fh-content-card__rank" aria-label="Rank <?php echo e($rank); ?>"><?php echo e($rank); ?></span>
            <?php endif; ?>

            <?php if(auth()->guard()->check()): ?>
                <button type="button" class="fh-content-card__add mylist-btn"
                        data-content-id="<?php echo e($content->id); ?>" data-in-list="<?php echo e($inList ? 'true' : 'false'); ?>"
                        aria-label="<?php echo e($inList ? 'Remove from My List' : 'Add to My List'); ?>"
                        title="<?php echo e($inList ? 'Remove from My List' : 'Add to My List'); ?>">
                    <svg class="mylist-icon-add <?php echo e($inList ? 'hidden' : ''); ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                    <svg class="mylist-icon-check <?php echo e($inList ? '' : 'hidden'); ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                </button>
            <?php endif; ?>

            <?php if($progress !== null && $progress > 0): ?>
                <div class="fh-content-card__progress" aria-label="<?php echo e($progress); ?>% complete"><span style="width: <?php echo e(min(100, max(0, $progress))); ?>%"></span></div>
            <?php endif; ?>
        </div>

        <div class="fh-content-card__details">
            <h3 class="fh-content-card__title" title="<?php echo e($content->title); ?>"><?php echo e($content->title); ?></h3>
            <div class="fh-content-card__meta">
                <span><?php echo e($typeLabel); ?></span>
                <?php if($content->year): ?>
                    <span class="fh-content-card__separator" aria-hidden="true">•</span>
                    <span><?php echo e($content->year); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </a>

    <?php if (isset($component)) { $__componentOriginald3b08a67ce4bee249aa12c2a049bc195 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald3b08a67ce4bee249aa12c2a049bc195 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bookmark-button','data' => ['content' => $content,'bookmarked' => $bookmarked,'showLabel' => true,'class' => 'fh-content-card__bookmark']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bookmark-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['content' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content),'bookmarked' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($bookmarked),'show-label' => true,'class' => 'fh-content-card__bookmark']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald3b08a67ce4bee249aa12c2a049bc195)): ?>
<?php $attributes = $__attributesOriginald3b08a67ce4bee249aa12c2a049bc195; ?>
<?php unset($__attributesOriginald3b08a67ce4bee249aa12c2a049bc195); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald3b08a67ce4bee249aa12c2a049bc195)): ?>
<?php $component = $__componentOriginald3b08a67ce4bee249aa12c2a049bc195; ?>
<?php unset($__componentOriginald3b08a67ce4bee249aa12c2a049bc195); ?>
<?php endif; ?>
</article>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\components\content-card.blade.php ENDPATH**/ ?>