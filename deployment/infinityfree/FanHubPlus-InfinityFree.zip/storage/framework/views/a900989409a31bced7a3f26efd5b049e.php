<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="fh-resource-page">
        <h1>Fan Resources</h1>
        <p>Community made files, reviewed before publication.</p>
        <?php if(auth()->guard()->check()): ?>
            <form method="POST" action="<?php echo e(route('resources.store')); ?>" enctype="multipart/form-data" class="fh-resource-form">
                <?php echo csrf_field(); ?>
                <label>Title <input name="title" required maxlength="255"></label>
                <label>Type
                    <select name="type" required>
                        <?php $__currentLoopData = ['wallpaper', 'fanart', 'fanfic', 'subtitle', 'theme', 'audio']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type); ?>"><?php echo e(ucfirst($type)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <label>Description <textarea name="description" rows="3"></textarea></label>
                <label>File <input name="file" type="file" required accept=".jpg,.jpeg,.png,.webp,.gif,.pdf,.mp3,.wav,.srt,.zip"></label>
                <label>License <input name="license" maxlength="100"></label>
                <button type="submit">Submit for review</button>
            </form>
        <?php endif; ?>
        <div class="fh-resource-grid">
            <?php $__empty_1 = true; $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="fh-resource-card">
                    <?php if (isset($component)) { $__componentOriginal866276d147fd9806dc1448ec1d213bc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal866276d147fd9806dc1448ec1d213bc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.media-image','data' => ['src' => $resource->thumbnailUrl(),'title' => $resource->title,'category' => $resource->content?->category?->name ?? $resource->type,'kind' => 'resource','alt' => $resource->title,'class' => 'w-full aspect-video object-cover rounded-lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('media-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($resource->thumbnailUrl()),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($resource->title),'category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($resource->content?->category?->name ?? $resource->type),'kind' => 'resource','alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($resource->title),'class' => 'w-full aspect-video object-cover rounded-lg']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $attributes = $__attributesOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $component = $__componentOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__componentOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
                    <h2><?php echo e($resource->title); ?></h2>
                    <p><?php echo e($resource->description); ?></p>
                    <p><?php echo e(ucfirst($resource->type)); ?> · <?php echo e(number_format($resource->file_size_kb)); ?> KB · <?php echo e($resource->download_count); ?> downloads</p>
                    <a href="<?php echo e(route('resources.download', $resource)); ?>">Download</a>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php if (isset($component)) { $__componentOriginal30ad060ffdcc6a54889af89351d7941e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal30ad060ffdcc6a54889af89351d7941e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.fh-empty-state','data' => ['title' => 'No resources yet','desc' => 'Approved fan resources will appear here.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('fh-empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'No resources yet','desc' => 'Approved fan resources will appear here.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal30ad060ffdcc6a54889af89351d7941e)): ?>
<?php $attributes = $__attributesOriginal30ad060ffdcc6a54889af89351d7941e; ?>
<?php unset($__attributesOriginal30ad060ffdcc6a54889af89351d7941e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30ad060ffdcc6a54889af89351d7941e)): ?>
<?php $component = $__componentOriginal30ad060ffdcc6a54889af89351d7941e; ?>
<?php unset($__componentOriginal30ad060ffdcc6a54889af89351d7941e); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
        <?php echo e($resources->links()); ?>

    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views/resources/index.blade.php ENDPATH**/ ?>