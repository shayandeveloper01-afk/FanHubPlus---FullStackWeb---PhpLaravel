<div class="space-y-5">
    <div>
        <label class="block text-sm text-gray-400 mb-1">Content</label>
        <select name="content_id" required class="w-full bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2">
            <option value="">— Select Content —</option>
            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($c->id); ?>" <?php echo e(old('content_id', $character->content_id ?? '') == $c->id ? 'selected' : ''); ?>><?php echo e($c->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['content_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-400 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
            <label class="block text-sm text-gray-400 mb-1">Name</label>
            <input type="text" name="name" value="<?php echo e(old('name', $character->name ?? '')); ?>" required
                   class="w-full bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-400 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label class="block text-sm text-gray-400 mb-1">Alias</label>
            <input type="text" name="alias" value="<?php echo e(old('alias', $character->alias ?? '')); ?>"
                   class="w-full bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2">
        </div>
        <div>
            <label class="block text-sm text-gray-400 mb-1">Role</label>
            <input type="text" name="role" value="<?php echo e(old('role', $character->role ?? '')); ?>"
                   class="w-full bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2">
        </div>
    </div>
    <div>
        <label class="block text-sm text-gray-400 mb-1" for="admin-character-image">Character image</label>
        <?php if(!empty($character?->image)): ?> <?php if (isset($component)) { $__componentOriginal866276d147fd9806dc1448ec1d213bc4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal866276d147fd9806dc1448ec1d213bc4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.media-image','data' => ['src' => $character->imageUrl(),'title' => $character->name,'category' => $character->content?->category?->name ?? 'Character','kind' => 'character','recordKey' => $character->id,'alt' => 'Current '.$character->name.' portrait','class' => 'w-32 h-32 object-cover rounded-lg border border-gray-700 mb-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('media-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($character->imageUrl()),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($character->name),'category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($character->content?->category?->name ?? 'Character'),'kind' => 'character','record-key' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($character->id),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Current '.$character->name.' portrait'),'class' => 'w-32 h-32 object-cover rounded-lg border border-gray-700 mb-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $attributes = $__attributesOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__attributesOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal866276d147fd9806dc1448ec1d213bc4)): ?>
<?php $component = $__componentOriginal866276d147fd9806dc1448ec1d213bc4; ?>
<?php unset($__componentOriginal866276d147fd9806dc1448ec1d213bc4); ?>
<?php endif; ?> <?php endif; ?>
        <input id="admin-character-image" type="file" name="image" accept="image/jpeg,image/png,image/webp" class="block w-full text-sm text-gray-300 file:mr-4 file:rounded-lg file:border-0 file:bg-indigo-600 file:px-4 file:py-2 file:text-white">
        <img id="admin-character-image-preview" alt="Selected character image preview" class="hidden mt-3 w-32 h-32 object-cover rounded-lg border border-purple-500/50">
        <p class="text-xs text-gray-500 mt-1">JPG, PNG or WebP, up to 2 MB.</p>
        <?php if(!empty($character?->image)): ?> <label class="mt-2 flex items-center gap-2 text-xs text-gray-400"><input type="checkbox" name="remove_image" value="1" class="rounded bg-gray-800 border-gray-600"> Remove current image</label> <?php endif; ?>
        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-400 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <script>document.getElementById('admin-character-image')?.addEventListener('change',event=>{const preview=document.getElementById('admin-character-image-preview');const file=event.target.files?.[0];if(file){preview.src=URL.createObjectURL(file);preview.classList.remove('hidden')}else{preview.removeAttribute('src');preview.classList.add('hidden')}});</script>
    </div>
    <div>
        <label class="block text-sm text-gray-400 mb-1">Description</label>
        <textarea name="description" rows="4"
                  class="w-full bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2"><?php echo e(old('description', $character->description ?? '')); ?></textarea>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views/admin/characters/_form.blade.php ENDPATH**/ ?>