<?php
    $keywordValue = old('keywords');
    if ($keywordValue === null) {
        $keywordValue = isset($faq) ? implode(', ', $faq->keywordList()) : '';
    } elseif (is_array($keywordValue)) {
        $keywordValue = implode(', ', $keywordValue);
    }
?>

<div>
    <label class="block text-sm text-gray-400 mb-1">Question</label>
    <input type="text" name="question" value="<?php echo e(old('question', $faq->question ?? request('question', ''))); ?>" required maxlength="500"
           class="w-full bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2">
    <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-400 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div>
    <label class="block text-sm text-gray-400 mb-1">Answer</label>
    <textarea name="answer" rows="5" required
              class="w-full bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2"><?php echo e(old('answer', $faq->answer ?? '')); ?></textarea>
    <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-400 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div>
    <label class="block text-sm text-gray-400 mb-1">Keywords <span class="text-gray-600 text-xs">(comma-separated, for search)</span></label>
    <input type="text" name="keywords" value="<?php echo e($keywordValue); ?>" maxlength="500"
           class="w-full bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2">
    <?php $__errorArgs = ['keywords'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-400 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="grid grid-cols-2 gap-4">
    <div>
        <label class="block text-sm text-gray-400 mb-1">Sort Order</label>
        <input type="number" name="sort_order" value="<?php echo e(old('sort_order', $faq->sort_order ?? 0)); ?>" min="0"
               class="w-full bg-gray-800 border border-gray-700 text-white text-sm rounded-lg px-3 py-2">
    </div>
    <div class="flex items-end pb-1">
        <label class="flex items-center gap-2 text-sm text-gray-400 cursor-pointer">
            <input type="checkbox" name="is_published" value="1"
                   <?php echo e(old('is_published', $faq->is_published ?? false) ? 'checked' : ''); ?>

                   class="rounded border-gray-600 bg-gray-800 text-indigo-600">
            Published
        </label>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\admin\faqs\_form.blade.php ENDPATH**/ ?>