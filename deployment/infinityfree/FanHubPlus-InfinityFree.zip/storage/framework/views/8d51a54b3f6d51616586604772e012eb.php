<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('head'); ?>
        <title>Add Merchandise — <?php echo e(config('app.name')); ?></title>
    <?php $__env->stopPush(); ?>

    <div class="fh-merch-editor max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <a href="<?php echo e(route('merchandise.index')); ?>" class="fh-merch-editor__back inline-flex items-center gap-1 text-sm text-gray-400 hover:text-white mb-6 transition">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
            Back
        </a>

        <header class="fh-merch-editor__hero">
            <span class="fh-merch-editor__eyebrow">FanHub+ Marketplace <i></i> Creator studio</span>
            <h1 class="fh-merch-editor__title">Add Merchandise</h1>
            <p class="fh-merch-editor__description">Create a standout listing fans will love. Add the details, set your price, and give it a polished gallery.</p>
            <div class="fh-merch-editor__meta"><span>✦ Premium listing</span><span>◈ Image gallery</span></div>
        </header>

        <form method="POST" action="<?php echo e(route('merchandise.store')); ?>" enctype="multipart/form-data"
              class="fh-merch-form space-y-6">
            <?php echo csrf_field(); ?>

            <?php echo $__env->make('merchandise._form', ['merchandise' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="fh-merch-form__actions flex gap-3 pt-2">
                <button type="submit"
                        class="fh-merch-submit px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg transition">
                    Create
                </button>
                <a href="<?php echo e(route('merchandise.index')); ?>"
                   class="fh-merch-cancel px-6 py-2.5 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition">
                    Cancel
                </a>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\merchandise\create.blade.php ENDPATH**/ ?>