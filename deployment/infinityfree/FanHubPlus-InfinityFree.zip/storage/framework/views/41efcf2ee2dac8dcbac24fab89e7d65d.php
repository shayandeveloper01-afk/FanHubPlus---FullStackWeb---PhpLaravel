<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-3">
            <a href="<?php echo e(route('admin.users.index')); ?>" class="text-gray-400 hover:text-white transition">← Users</a>
            <span class="text-gray-600">/</span>
            <h1 class="text-lg font-semibold text-white"><?php echo e($user->name); ?></h1>
        </div>
     <?php $__env->endSlot(); ?>

        <div class="max-w-4xl space-y-6">
        <div class="bg-gray-900 border border-gray-800 rounded-xl p-6 flex items-center gap-5">
            <img src="<?php echo e($user->avatarUrl()); ?>" class="h-16 w-16 rounded-full object-cover">
            <div>
                <h2 class="text-xl font-bold text-white"><?php echo e($user->name); ?></h2>
                <p class="text-gray-400 text-sm"><?php echo e($user->email); ?></p>
                <div class="flex gap-2 mt-2">
                    <?php if($user->is_admin): ?>
                        <span class="px-2 py-0.5 text-xs rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">Admin</span>
                    <?php endif; ?>
                    <?php if($user->isBanned()): ?>
                        <span class="px-2 py-0.5 text-xs rounded-full bg-red-500/20 text-red-300 border border-red-500/40">Banned since <?php echo e($user->banned_at->format('d M Y')); ?></span>
                    <?php endif; ?>
                    <?php if($user->trashed()): ?>
                        <span class="px-2 py-0.5 text-xs rounded-full bg-gray-700 text-gray-400 border border-gray-600">Deleted <?php echo e($user->deleted_at->format('d M Y')); ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <?php $__currentLoopData = [
                ['label' => 'Content',   'value' => $user->contents()->count()],
                ['label' => 'Articles',  'value' => $user->articles()->count()],
                ['label' => 'Bookmarks', 'value' => $user->bookmarks()->count()],
                ['label' => 'Ratings',   'value' => $user->ratings()->count()],
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-gray-900 border border-gray-800 rounded-xl p-4 text-center">
                <p class="text-2xl font-bold text-indigo-400"><?php echo e($stat['value']); ?></p>
                <p class="text-xs text-gray-500 mt-1"><?php echo e($stat['label']); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <section class="overflow-hidden rounded-xl border border-gray-800 bg-gray-900">
            <div class="flex items-center justify-between gap-3 border-b border-gray-800 px-5 py-4">
                <div>
                    <h2 class="font-semibold text-white">User ratings &amp; reviews</h2>
                    <p class="mt-1 text-xs text-gray-500">All star ratings are stored here; review text is public after admin approval.</p>
                </div>
                <a href="<?php echo e(route('admin.reviews.index', ['status' => 'all'])); ?>" class="text-sm font-medium text-violet-300 hover:text-white">Review panel</a>
            </div>
            <div class="divide-y divide-gray-800">
                <?php $__empty_1 = true; $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <article class="px-5 py-4">
                        <div class="flex flex-wrap items-center justify-between gap-2">
                            <p class="font-medium text-white"><?php echo e($rating->content?->title ?? 'Deleted content'); ?></p>
                            <div class="flex items-center gap-2">
                                <span class="text-amber-300"><?php echo e($rating->rating); ?>/5</span>
                                <?php if($rating->review): ?>
                                    <span class="rounded-full px-2 py-0.5 text-xs <?php echo e($rating->review_status === 'approved' ? 'bg-emerald-500/10 text-emerald-300' : ($rating->review_status === 'rejected' ? 'bg-rose-500/10 text-rose-300' : 'bg-amber-500/10 text-amber-300')); ?>"><?php echo e(ucfirst($rating->review_status ?? 'pending')); ?></span>
                                <?php else: ?>
                                    <span class="text-xs text-gray-500">Rating only</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php if($rating->review): ?><p class="mt-2 whitespace-pre-line text-sm text-gray-300"><?php echo e($rating->review); ?></p><?php endif; ?>
                        <p class="mt-2 text-xs text-gray-600"><?php echo e($rating->created_at?->format('M j, Y g:i A')); ?></p>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="px-5 py-6 text-sm text-gray-500">This user has not rated any content.</p>
                <?php endif; ?>
            </div>
        </section>

        <section class="overflow-hidden rounded-xl border border-gray-800 bg-gray-900">
            <div class="flex items-center justify-between border-b border-gray-800 px-5 py-4">
                <div>
                    <h2 class="font-semibold text-white">Contact form messages</h2>
                    <p class="mt-1 text-xs text-gray-500">Replies and reactions are managed in Feedback and shown to the user in My messages.</p>
                </div>
                <a href="<?php echo e(route('admin.feedback.index')); ?>" class="text-sm font-medium text-violet-300 hover:text-white">Feedback inbox</a>
            </div>
            <div class="divide-y divide-gray-800">
                <?php $__empty_1 = true; $__currentLoopData = $feedbackMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
                        <div>
                            <p class="font-medium text-white"><?php echo e($message->subject); ?></p>
                            <p class="mt-1 text-xs text-gray-500"><?php echo e($message->reference_code); ?> · <?php echo e($message->statusLabel()); ?> · <?php echo e($message->created_at?->format('M j, Y')); ?></p>
                        </div>
                        <a href="<?php echo e(route('admin.feedback.show', $message)); ?>" class="text-sm text-indigo-300 hover:text-white">Open &amp; reply</a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="px-5 py-6 text-sm text-gray-500">No contact form messages from this user.</p>
                <?php endif; ?>
            </div>
        </section>

        <div class="grid gap-4 rounded-xl border border-gray-800 bg-gray-900 p-5 text-sm sm:grid-cols-2">
            <div>
                <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Account created</p>
                <p class="mt-1 text-white"><?php echo e($user->created_at?->timezone(config('app.timezone'))->format('d F Y \\a\\t h:i A') ?? 'Unavailable'); ?></p>
                <p class="mt-1 text-xs text-gray-500">Live from the account record · <?php echo e(config('app.timezone')); ?></p>
            </div>
            <div>
                <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Current password last set / changed</p>
                <?php if($user->password_changed_at): ?>
                    <p class="mt-1 text-white"><?php echo e($user->password_changed_at->timezone(config('app.timezone'))->format('d F Y \\a\\t h:i A')); ?></p>
                    <p class="mt-1 text-xs text-gray-500">Exact timestamp saved when the password was last changed or reset.</p>
                <?php else: ?>
                    <p class="mt-1 text-white"><?php echo e($user->created_at?->timezone(config('app.timezone'))->format('d F Y \\a\\t h:i A') ?? 'Not recorded'); ?></p>
                    <p class="mt-1 text-xs text-amber-300">Estimate from account creation; this older account's exact password-change date was not stored. Future changes and resets will show the exact time.</p>
                <?php endif; ?>
            </div>
            <div>
                <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Account last updated</p>
                <p class="mt-1 text-white"><?php echo e($user->updated_at?->timezone(config('app.timezone'))->format('d F Y \\a\\t h:i A') ?? 'Unavailable'); ?></p>
            </div>
            <div>
                <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Email verified</p>
                <p class="mt-1 text-white"><?php echo e($user->email_verified_at?->timezone(config('app.timezone'))->format('d F Y \\a\\t h:i A') ?? 'No'); ?></p>
            </div>
            <div class="sm:col-span-2 border-t border-gray-800 pt-3">
                <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Website data first recorded</p>
                <p class="mt-1 text-white"><?php echo e($firstSiteRecordAt?->timezone(config('app.timezone'))->format('d F Y \\a\\t h:i A') ?? 'No dated records found'); ?></p>
                <p class="mt-1 text-xs text-gray-500">Calculated from the earliest user, content, category, article, or contact record. This is the earliest database activity; a separate website launch date is not stored.</p>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Fan_Hub_Plus2\resources\views\admin\users\show.blade.php ENDPATH**/ ?>